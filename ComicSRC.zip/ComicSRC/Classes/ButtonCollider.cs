using UnityEngine;
using UnityEngine.Networking;
using Photon.Pun;
using static StupidTemplate.Menu.Main;
using static StupidTemplate.Settings;
using AetherTemp.Mods;

namespace StupidTemplate.Classes
{
    internal class Button : MonoBehaviour
    {
        public string relatedText;
        public static float buttonCooldown = 0f;

        public void OnTriggerEnter(Collider collider)
        {
            if (Time.time > buttonCooldown && collider == buttonCollider && menu != null)
            {
                buttonCooldown = Time.time + 0.2f;
                GorillaTagger.Instance.StartVibration(rightHanded, 0.5f, 0.2f);
                GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(169, rightHanded, 0.4f);
                //SoundBoard.PlayAudioCS("https://raw.githubusercontent.com/boxxin/clcik/main/Whip-sound-effect%20(2).wav");
                Toggle(relatedText);
            }
        }
    }
}