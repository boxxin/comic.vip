﻿using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

namespace AetherTemp.Classes
{
    public class BetterColors
    {
        public static Color white = Color.white;
        public static Color black = Color.black;
        public static Color red = Color.red;
        public static Color green = Color.green;
        public static Color blue = Color.blue;
        public static Color yellow = Color.yellow;
        public static Color cyan = Color.cyan;
        public static Color magenta = Color.magenta;
        public static Color gray = Color.gray;
        public static Color grey = Color.grey;
        public static Color32 darkRed = new Color(139, 0,0,255);
        public static Color32 dark = new Color32(10, 10, 10, 255);
        public static Color32 darkGrey = new Color32(30, 30, 30, 255);
        public static Color32 darkGreen = new Color32(0,139,0,255);
        public static Color32 darkBlue = new Color32(0, 0, 139, 255);
        public static Color32 cyan2 = new Color32(0, 102, 102, 255);
        public static Color32 darkCyan = new Color32(0, 153, 153, 255);
        public static Color32 lightPurple = new Color32(153, 153, 255, 255);
        public static Color32 ogComicColor = new Color32(49, 32, 73, 255);
        public static Color32 pink = new Color32(242, 213, 246, 255);
        public static Color32 hotPink = new Color32(255, 105, 180, 255);
        public static Color32 lightPink = new Color32(242, 173, 241, 255);
        public static Color32 iidkColor = new Color32(255, 102, 0, 128);
        public static Color32 iidkColorButton = new Color32(85, 42, 0, 255);
        public static Color32 iidkColorButtonDis = new Color32(170, 85, 0, 255);
    }
}
