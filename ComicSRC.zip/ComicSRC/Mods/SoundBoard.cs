﻿using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine.Networking;
using UnityEngine;
using Photon.Voice.Unity;

namespace AetherTemp.Mods
{
    internal class SoundBoard
    {
        public static float RecoverTime;
        public static AudioSource localSource;

        public static void PlayAudio(string githubRawUrl)
        {
            AudioClip sound = LoadSoundFromGitHub(githubRawUrl);
            if (sound == null)
            {
                Debug.LogError("Failed to load audio.");
                return;
            }
            var recorder = GorillaTagger.Instance.myRecorder;
            recorder.SourceType = Recorder.InputSourceType.AudioClip;
            recorder.AudioClip = sound;
            recorder.RestartRecording(true);
            recorder.DebugEchoMode = true;
            RecoverTime = Time.time + sound.length;
        }
        public static void PlayAudioCS(string githubRawUrl)
        {
            AudioClip sound = LoadSoundFromGitHub(githubRawUrl);
            if (sound == null)
            {
                Debug.LogError("Failed to load audio.");
                return;
            }
            if (localSource == null)
            {
                GameObject audioObj = new GameObject("AudioObj");
                localSource = audioObj.AddComponent<AudioSource>();
                localSource.volume = 1f;
                localSource.playOnAwake = false;
            }
            localSource.transform.position = GorillaLocomotion.GTPlayer.Instance.headCollider.transform.position;
            localSource.clip = sound;
            localSource.loop = false;
            localSource.Play();
            RecoverTime = Time.time + sound.length;
        }
        public static void playhh()
        {
            PlayAudio("https://raw.githubusercontent.com/boxxin/clcik/main/0523(1).WAV");
        }

        private static AudioClip LoadSoundFromGitHub(string url)
        {
            using (UnityWebRequest www = UnityWebRequestMultimedia.GetAudioClip(url, AudioType.WAV))
            {
                www.SendWebRequest();
                while (!www.isDone) { }
                if (www.result == UnityWebRequest.Result.Success)
                {
                    return DownloadHandlerAudioClip.GetContent(www);
                }
                return null;
            }
        }
    }
}
