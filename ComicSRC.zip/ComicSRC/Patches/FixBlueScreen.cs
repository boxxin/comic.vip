﻿using System.Threading.Tasks;
using BepInEx;
using UnityEngine;

namespace AetherTemp.Patches
{
    [BepInPlugin("org.bossin.gorillatag.fixbluescrren", "fixblue", "1.0")]
    public class FixBlueScreen : BaseUnityPlugin
    {
        public void Start()
        {
            GorillaTagger.OnPlayerSpawned(WaitTillLoaded);
        }

        public async void WaitTillLoaded()
        {
            while (Time.time <= 0.01f)
            {
                await Task.Delay(1);
            }
            LinqUtils.ForEach(Resources.FindObjectsOfTypeAll<PrivateUIRoom>(), DestoryObj);
            Logger.LogInfo("Deleted PrivateUIRoom Objects!");
            void DestoryObj(PrivateUIRoom PUIR)
            {
                Logger.LogInfo("Deleting Object \"" + (PUIR).name + "\"..");
                DestroyImmediate(PUIR.gameObject);
            }
        }
    }

}
