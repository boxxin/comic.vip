﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace AetherTemp.Notifications
{
    public class notif2
    {
        public static List<GameObject> activeNotifs = new List<GameObject>();
        public static void DrawNotif(string message)
        {
            Transform head = GorillaLocomotion.GTPlayer.Instance.headCollider.transform;
            if (head == null) return;

            GameObject notif = new GameObject("bossin");
            TextMesh tm = notif.AddComponent<TextMesh>();
            tm.text = message;
            tm.fontSize = 50;
            tm.characterSize = 0.02f;
            tm.anchor = TextAnchor.MiddleCenter;
            tm.alignment = TextAlignment.Center;
            tm.color = new Color(1, 1, 1, 0);
            tm.fontStyle = FontStyle.Bold;

            fade fader = notif.AddComponent<fade>();
            fader.target = tm;
            fader.index = activeNotifs.Count;

            activeNotifs.Add(notif);
        }

        public class fade : MonoBehaviour
        {
            public TextMesh target;
            public float timer;
            public int index;

            public void OnDestroy()
            {
                activeNotifs.Remove(gameObject);
                for (int i = 0; i < activeNotifs.Count; i++)
                {
                    activeNotifs[i].GetComponent<fade>().index = i;
                }
            }

            public void Update()
            {
                if (GorillaLocomotion.GTPlayer.Instance.headCollider.transform == null) return;
                timer += Time.deltaTime;
                Vector3 baseOffset = GorillaLocomotion.GTPlayer.Instance.headCollider.transform.forward * -1.5f + Vector3.up * (-0.3f + -0.2f * index);
                transform.position = GorillaLocomotion.GTPlayer.Instance.headCollider.transform.position + baseOffset;
                transform.rotation = Quaternion.LookRotation(transform.position - GorillaLocomotion.GTPlayer.Instance.headCollider.transform.position);
                if (timer < 0.5f)
                {
                    float t = timer / 0.5f;
                    target.color = new Color(1, 1, 1, t);
                }
                else if (timer < 2f)
                {
                    target.color = new Color(1, 1, 1, 1);
                }
                else if (timer < 2.5f)
                {
                    float t = 1f - ((timer - 2f) / 0.5f);
                    target.color = new Color(1, 1, 1, t);
                }
                else
                {
                    Destroy(gameObject);
                }
            }
        }
    }
}