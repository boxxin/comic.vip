﻿namespace StupidTemplate
{
    internal class PluginInfo
    {
        public const string GUID = "org.boxxin.gorillatag.comic";
        public const string Name = "comic.vip V3";
        public const string Description = "Created by @box.xin with love <3";
        public const string Version = "2.0.0";
    }
}
