﻿using AetherTemp.Classes;
using BepInEx;
using GorillaNetworking;
using Photon.Pun;
using PlayFab.ClientModels;
using StupidTemplate;
using StupidTemplate.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using UnityEngine.InputSystem;

namespace AetherTemp.Menu
{
    [BepInPlugin("boii.ts.gui", "comic.gui", "1.0.0")]
    public class poopgui : BaseUnityPlugin
    {
        public static string[] buttons = new string[9999];
        public static string strang = "";

        public void OnGUI()
        {
            List<string> strings = new List<string>();
            foreach (ButtonInfo[] buttonInfos in Buttons.buttons)
            {
                foreach (ButtonInfo buttonInfo in buttonInfos)
                {
                    if (buttonInfo.enabled)
                    {
                        strings.Add(buttonInfo.buttonText);
                    }
                }
            }
            strings.Sort();
            int i = 0;
            for (int l = 0; l < buttons.Count(); l++)
            {
                buttons[i] = "";
                i++;
            }
            i = 0;
            foreach (string strig in strings)
            {
                buttons[i] += "|" + strig + "|\n";
                if (Settings.animtaingText)
                {
                    string duhh2 = buttons[i];
                    string updated2 = "";
                    float t2 = Mathf.PingPong(Time.time, 1f);
                    int num2;
                    for (int j = 0; j < duhh2.Length; j = num2 + 1)
                    {
                        float letterPos = (float)j / (float)(duhh2.Length - 1);
                        float blend = Mathf.PingPong(Time.time + letterPos, 1f);
                        Color color = Color.Lerp(Color.white, Settings.buuu, blend);
                        updated2 += $"<color=#{ColorUtility.ToHtmlStringRGB(color)}>{duhh2[j]}</color>";
                        num2 = j;
                    }
                    buttons[i] = updated2;
                }
                i++;
            }
            strang = string.Join("", buttons);
            GUI.skin.label.fontSize = 16;
            GUI.skin.label.font = Settings.currentFont;
            GUI.skin.label.alignment = TextAnchor.UpperRight;
            GUI.Label(new Rect(0, 0, Screen.width - 20f, Screen.height), strang);
        }
    }
       
        
}
