﻿using GorillaTag.Cosmetics.Summer;
using StupidTemplate.Classes;
using StupidTemplate.Menu;
using StupidTemplate.Mods;
using static StupidTemplate.Settings;
using UnityEngine;
using GorillaTag.Cosmetics;
using StupidTemplate;
using GorillaNetworking;
using Photon.Pun;
using Photon.Voice.Unity.UtilityScripts;
using AetherTemp.Mods;
using static StupidTemplate.Menu.mods;

namespace AetherTemp.Menu
{
    internal class Buttons
    {
        public static void fff()
        {
           
        }
        public static void flipmenu()
        {
            flipMenu = true;
        }
        public static void dontflipmenu()
        {
            flipMenu = false;
        }
        public static ButtonInfo[][] buttons = new ButtonInfo[][]
        {
            new ButtonInfo[] { // Main Mods
                new ButtonInfo { buttonText = "Settings", method =() => SettingsMods.SwitchPage(1), isTogglable = false, toolTip = "Opens the main settings page for the menu."},
                new ButtonInfo { buttonText = "Main", method =() => SettingsMods.SwitchPage(5), isTogglable = false, toolTip = "Opens the home page for the menu."},
                new ButtonInfo { buttonText = "Movement", method =() => SettingsMods.SwitchPage(8), isTogglable = false, toolTip = "Opens the movement page for the menu."},
                new ButtonInfo { buttonText = "Room", method =() => SettingsMods.SwitchPage(6), isTogglable = false, toolTip = "Opens the room page for the menu."},
                new ButtonInfo { buttonText = "Comp", method =() => SettingsMods.SwitchPage(7), isTogglable = false, toolTip = "Opens the comp page for the menu."},
                new ButtonInfo { buttonText = "Advantage", method =() => SettingsMods.SwitchPage(9), isTogglable = false, toolTip = "Opens the advantage page for the menu."},
                new ButtonInfo { buttonText = "Visual", method =() => SettingsMods.SwitchPage(10), isTogglable = false, toolTip = "Opens the Visual page for the menu."},
            },

            new ButtonInfo[] { // Main Settings
                new ButtonInfo { buttonText = "Menu Settings", method =() => SettingsMods.SwitchPage(3), isTogglable = false, toolTip = "Opens the menu settings for the menu."},
                new ButtonInfo { buttonText = "GunLib Settings", method =() => SettingsMods.SwitchPage(2), isTogglable = false, toolTip = "Opens the gunlib settings for the menu."},
                new ButtonInfo { buttonText = "Notif Settings", method =() => SettingsMods.SwitchPage(4), isTogglable = false, toolTip = "Opens the notif settings for the menu."},
                new ButtonInfo { buttonText = "Visual Settings", method =() => SettingsMods.SwitchPage(11), isTogglable = false, toolTip = "Opens the visual settings for the menu."},
                new ButtonInfo { buttonText = "Movement Settings", method =() => SettingsMods.SwitchPage(12), isTogglable = false, toolTip = "Opens the visual settings for the menu."},
            },


            new ButtonInfo[] { // GunLib
                new ButtonInfo { buttonText = "Equip Gun", method =() => mods.GunTemplate(fff, false), isTogglable = true, toolTip = "Equips a gun."},
                new ButtonInfo { buttonText = $"Smoothness: {(mods.num == 5f ? "Very Fast" : mods.num == 10f ? "Normal" : "Super Smooth")}", method = () => { mods.GunSmoothNess(); foreach (var category in Buttons.buttons) foreach (var button in category) if (button.buttonText.StartsWith("Smoothness")) button.buttonText = $"Smoothness: {(mods.num == 5f ? "Super Smooth" : mods.num == 10f ? "Normal" : "No Smooth")}"; }, isTogglable = false, toolTip = "Changes gun smoothness." },
                new ButtonInfo { buttonText = "Toggle Sphere", method = () => { mods.isSphereEnabled = !mods.isSphereEnabled; if (GunSphere != null) mods.GunSphere.transform.localScale = mods.isSphereEnabled ? new Vector3(0.1f, 0.1f, 0.1f) : new Vector3(0f, 0f, 0f); foreach (var category in Buttons.buttons) foreach (var button in category) if (button.buttonText.StartsWith("Toggle Sphere Size")) button.buttonText = $"Toggle Sphere Size: {(mods.isSphereEnabled ? "Enabled" : "Disabled")}"; }, isTogglable = false, toolTip = "Toggles the size of the gun sphere." }
            },

            new ButtonInfo[] { // MenuSettings
                 new ButtonInfo { buttonText = "Change Menu Theme", method =() => ChangeTheme(), isTogglable = false, toolTip = "Changes The Menu Theme"},
                new ButtonInfo { buttonText = "Right/Left Hand", enableMethod =() => SettingsMods.RightHand(), disableMethod =() => SettingsMods.LeftHand(), toolTip = "Puts the menu on your right hand."},
                new ButtonInfo { buttonText = "Flip Menu", enableMethod =() => flipmenu(), disableMethod =() => dontflipmenu(), isTogglable = true, enabled = false },
                new ButtonInfo { buttonText = "FPS Counter", enableMethod =() => SettingsMods.EnableFPSCounter(), disableMethod =() => SettingsMods.DisableFPSCounter(), enabled = fpsCounter, toolTip = "Toggles the FPS counter."},
                new ButtonInfo { buttonText = "Disconnect Button", enableMethod =() => SettingsMods.EnableDisconnectButton(), disableMethod =() => SettingsMods.DisableDisconnectButton(), enabled = disconnectButton, toolTip = "Toggles the disconnect button."},
                new ButtonInfo { buttonText = $"Delete Time: {(Main.num == 2f ? "Default" : Main.num == 5f ? "Long" : "Fast")}", method = () => { Main.MenuDeleteTime(); foreach (var category in Buttons.buttons) foreach (var button in category) if (button.buttonText.StartsWith("Delete Time")) button.buttonText = $"Delete Time: {(Main.num == 2f ? "Default" : Main.num == 5f ? "Long" : "Fast")}"; }, isTogglable = false, toolTip = "Changes menu delete time." },
                new ButtonInfo { buttonText = "Disable Menu Text", enableMethod =() => mods.DisableMenuText(), disableMethod =() => mods.EnableMenuText(), isTogglable = true, enabled = true },
                new ButtonInfo { buttonText = "Toggle Page Buttons", enableMethod =() => EnablePageButtons(), disableMethod =() => DisablePageButtons(), isTogglable = true, enabled = false },
                new ButtonInfo { buttonText = "Toggle Orbiting Sphere", enableMethod =() => EnableOrbitSphere(), disableMethod =() => DisableOrbitSphere(), isTogglable = true, enabled = true },
                new ButtonInfo { buttonText = "Toggle Round Menu", enableMethod =() => EnableRound(), disableMethod =() => DisableRound(), isTogglable = true, enabled = true },
                new ButtonInfo { buttonText = "Toggle Outline Menu", enableMethod =() => EnableOutlines(), disableMethod =() => DisableOutlines(), isTogglable = true, enabled = true },
                new ButtonInfo { buttonText = "Toggle Animating Text", enableMethod =() => EnableAnimatingText(), disableMethod =() => DisableAnimatingText(), isTogglable = true, enabled = true },

    },

            new ButtonInfo[] { // Notifications
                new ButtonInfo { buttonText = "Notifications", enableMethod =() => SettingsMods.EnableNotifications(), disableMethod =() => SettingsMods.DisableNotifications(), enabled = !disableNotifications, toolTip = "Toggles the notifications."},
                new ButtonInfo { buttonText = $"Notif Delete Time: {(Main.num2 == 2f ? "Default" : Main.num2 == 5f ? "Long" : "Fast")}", method = () => { Main.NotifDeleteTime(); foreach (var category in Buttons.buttons) foreach (var button in category) if (button.buttonText.StartsWith("Delete Time")) button.buttonText = $"Delete Time: {(Main.num2 == 2f ? "Default" : Main.num2 == 5f ? "Long" : "Fast")}"; }, isTogglable = false, toolTip = "Changes notif delete time." },
            },
            new ButtonInfo[] { // home
                new ButtonInfo { buttonText = "Join Discord", method =() => Home.JoinDiscord(),enabled = false, isTogglable = false, toolTip = "Joins the discord server."},
                new ButtonInfo { buttonText = "FPC", method =() => FPC(),enabled = false, isTogglable = true, toolTip = "Makes it so you cant move your fingers."},
                new ButtonInfo { buttonText = "Get All RPCS", method =() => Home.GetAllRPCS(),enabled = false, isTogglable = false, toolTip = "Gets all rpcs and puts the in a file"},
                new ButtonInfo { buttonText = "No Finger Movement", method =() => Home.RemoveFingerMovement(),enabled = false, isTogglable = true, toolTip = "Makes it so you cant move your fingers."},
                new ButtonInfo { buttonText = "Disable Network Triggers", enableMethod =() => DisableNetworkTriggers(), disableMethod=()=> EnableNetworkTriggers(), enabled = false, isTogglable = true, toolTip = "Makes it so you cant move your fingers."},
            },
            new ButtonInfo[] { // room
                new ButtonInfo { buttonText = "Play HH By Kanye",method =() => SoundBoard.playhh(), enabled = false, isTogglable = false, toolTip = "Disconnects you. Common sense"},
                new ButtonInfo { buttonText = "Disconnect",method =() => Disconnect(), enabled = false, isTogglable = false, toolTip = "Disconnects you. Common sense"},
                new ButtonInfo { buttonText = "Disconnect [RT]",method =() => DisconnectRT(), enabled = false, toolTip = "Disconnects you. But with your right trigger"},
                new ButtonInfo { buttonText = "Disconnect [RG]",method =() => DisconnectRG(), enabled = false, toolTip = "Disconnects you. But with your right grip"},
                new ButtonInfo { buttonText = "Disconnect [RJ]",method =() => DisconnectRJ(), enabled = false, toolTip = "Disconnects you. But with your right joystick"},
            },
            new ButtonInfo[]
            {
                new ButtonInfo { buttonText = "Unnoticable speed boost", method =() => WeakSpeedBoost(), isTogglable = true},
                new ButtonInfo { buttonText = "Decent speed boost", method =() => DecentSpeedBoost(), isTogglable = true},
                new ButtonInfo { buttonText = "Good speed boost", method =() => GoodSpeedBoost(), isTogglable = true},
                new ButtonInfo { buttonText = "Fast speed boost", method =() => StrongSpeedBoost(), isTogglable = true},
                new ButtonInfo { buttonText = "Super fast speed boost", method =() => SuperSpeedBoost(), isTogglable = true},
                new ButtonInfo { buttonText = "Unnoticable speed boost [rg]", method =() => WeakGripSpeedBoost(), isTogglable = true},
                new ButtonInfo { buttonText = "Decent speed boost [rg]", method =() => DecentGripSpeedBoost(), isTogglable = true},
                new ButtonInfo { buttonText = "Good speed boost [rg]", method =() => GoodGripSpeedBoost(), isTogglable = true},
                new ButtonInfo { buttonText = "Fast speed boost [rg]", method =() => StrongGripSpeedBoost(), isTogglable = true},
                new ButtonInfo { buttonText = "Super fast speed boost [rg]", method =() => SuperGripSpeedBoost(), isTogglable = true},
                new ButtonInfo { buttonText = "Unnoticable pull mod [rg]", method =() => UnnoticablePullMod(), isTogglable = true},
                new ButtonInfo { buttonText = "Mid pull mod [rg]", method =() => MidPullMod(), isTogglable = true},
                new ButtonInfo { buttonText = "Strong pull mod [rg]", method =() => StrongPullMod(), isTogglable = true},
                new ButtonInfo { buttonText = "Low HZ", method =() => hz(), isTogglable = true},
                new ButtonInfo { buttonText = "Unnoticable long arms", method =() => unnotic(), isTogglable = false},
                new ButtonInfo { buttonText = "Mid long arms", method =() => mid(), isTogglable = false},
                new ButtonInfo { buttonText = "Long long arms", method =() => longg(), isTogglable = false},
                new ButtonInfo { buttonText = "Reset Arm Length", method =() => fix(), isTogglable = false},
                new ButtonInfo { buttonText = "Predictions", method =() => press(), isTogglable = true},
            },
            new ButtonInfo[] { // move
                new ButtonInfo { buttonText = "Platforms [G]", method =() => Platforms(false),enabled = false, isTogglable = true, toolTip = "Platforms, Common Sense"},
                new ButtonInfo { buttonText = "Platforms [T]", method =() => Platforms(true),enabled = false, isTogglable = true, toolTip = "Platforms, But With Triggers"},
                new ButtonInfo { buttonText = "Fly [B]", method =() => Fly(),enabled = false, isTogglable = true, toolTip = "Use B To Fly"},
                new ButtonInfo { buttonText = "Noclip Fly [B]", enableMethod =() => NoclipFly(),disableMethod =() => EnableMeshColliders(), enabled = false, isTogglable = true, toolTip = "Use B To Fly"},
                new ButtonInfo { buttonText = "Velocity Fly [B]", method =() => VelocityFly(),enabled = false, isTogglable = true, toolTip = "Use B To Fly [Super Fast]"},
                new ButtonInfo { buttonText = "Zero Gravity", enableMethod =() => ZeroGrav(), disableMethod =() => FixGrav(), enabled = false, isTogglable = true, toolTip = "Use B To Fly [Super Fast]"},
                new ButtonInfo { buttonText = "TP Gun", method =() => GunTemplate(() => TPGun(), false),enabled = false, isTogglable = true, toolTip = "Use B To Fly [Slow]"},
                new ButtonInfo { buttonText = "Rig Gun", method =() => GunTemplate(() => RigGun(), false),enabled = false, isTogglable = true, toolTip = "Use B To Fly [Slow]"},
                new ButtonInfo { buttonText = "Noclip [RT]", enableMethod =() => Noclip(), disableMethod =() => EnableMeshColliders(), enabled = false, isTogglable = true, toolTip = "Use B To Fly [Slow]"},
                new ButtonInfo { buttonText = "Speed Boost", method =() => SpeedBoost(), isTogglable = true},
                new ButtonInfo { buttonText = "Speed Boost [RG]", method =() => GripSpeedBoost(), isTogglable = true},
            },
             new ButtonInfo[] { // advantage
                 new ButtonInfo { buttonText = "Tag Self [RT]", method =() => TagSelf(), isTogglable = true, toolTip = "Disconnected from lobby."},
                 new ButtonInfo { buttonText = "Tag Gun", method =() => GunTemplate(() => TagGun(lockedVRRig), true), isTogglable = true, toolTip = "Disconnected from lobby."},
                 new ButtonInfo { buttonText = "Tag All [RT]", method =() => TagAll(), isTogglable = true, toolTip = "Disconnected from lobby."},
                 new ButtonInfo { buttonText = "Tag Aura [LAGGY][RG]", method =() => TagAura(), isTogglable = true, toolTip = "Disconnected from lobby."},
             },

             new ButtonInfo[] { // Visual
                 new ButtonInfo { buttonText = "Tracers", method =() => Tracers(), isTogglable = true, toolTip = "Disconnected from lobby."},
                 new ButtonInfo { buttonText = "Chat GPT ESP Test", enableMethod =() => ChatGPTESP(), disableMethod =() => ClearAllESP(), isTogglable = true, toolTip = "Disconnected from lobby."},
                 new ButtonInfo { buttonText = "Trails", enableMethod =() => TrailPlayers(),disableMethod =()=> DestroyTrails(), isTogglable = true, toolTip = "Disconnected from lobby."},
                 new ButtonInfo { buttonText = "Chams", method =() => Chams(), isTogglable = true, toolTip = "Disconnected from lobby."},
                 new ButtonInfo { buttonText = "Chams Self", method =() => ChamsSelf(), isTogglable = true, toolTip = "Disconnected from lobby."},
                 new ButtonInfo { buttonText = "Day Time", method =() => DayTime(), isTogglable = false, toolTip = "Disconnected from lobby."},
                 new ButtonInfo { buttonText = "Morning Time", method =() => MorningTime(), isTogglable = false, toolTip = "Disconnected from lobby."},
                 new ButtonInfo { buttonText = "Night Time", method =() => NightTime(), isTogglable = false, toolTip = "Disconnected from lobby."},
                 new ButtonInfo { buttonText = "Enable Rain", enableMethod =() => EnableAllRain(),disableMethod =() => DisableAllRain(), isTogglable = true, toolTip = "Disconnected from lobby."},
             },

             new ButtonInfo[] { // Visual Settings
                new ButtonInfo { buttonText = "Follow Menu Theme", enableMethod =() => FollowTheme(), disableMethod =() => DontFollowTheme(), isTogglable = true, enabled = false },
             },
             new ButtonInfo[] { // Movement Settings
                new ButtonInfo { buttonText = "Hand Fly", enableMethod =() => EnableHandFly(), disableMethod =() => DisableHandFly(), isTogglable = true, enabled = false },
                new ButtonInfo { buttonText = "Change Fly Speed", method =() => ChangeFlySpeed(), isTogglable = false, enabled = false },
                new ButtonInfo { buttonText = "Change Vel Fly Speed", method =() => ChangeVelFlySpeed(), isTogglable = false, enabled = false },
                new ButtonInfo { buttonText = "Change Speed Boost Jump Multi", method =() => ChangeJumpMulti(), isTogglable = false, enabled = false },
                new ButtonInfo { buttonText = "Change Speed Boost Max Jump Speed", method =() => ChangeMaxJumpSpeed(), isTogglable = false, enabled = false },
             },

             new ButtonInfo[] {
                 new ButtonInfo { buttonText = "Disconnect", method =() => Disconnect(), isTogglable = false, toolTip = "Disconnected from lobby."},
             },
           
            new ButtonInfo[] {
                new ButtonInfo { buttonText = "home", method =() => Global.ReturnHome(), isTogglable = false, toolTip = "Opens the home for the menu."},
            },

        };
    }
}
