﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BepInEx;
using GorillaNetworking;
using Photon.Pun;
using UnityEngine;
using TMPro;
using UnityEngine.InputSystem;
using StupidTemplate.Notifications;
using ExitGames.Client.Photon;
using Photon.Realtime;
using HarmonyLib;
using AetherTemp.Menu;
using System.Text.RegularExpressions;
using StupidTemplate.Patches;
using System.Reflection;
using System.Net;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Buffers.Text;
using Valve.VR;
using GorillaTagScripts;
using System.Threading;
using StupidTemplate.Mods;
using Color = UnityEngine.Color;
using GorillaLocomotion.Climbing;
using GorillaLocomotion;
using StupidTemplate.Classes;
using static StupidTemplate.Settings;
using AetherTemp.Classes;
using Cinemachine;
using static StupidTemplate.Menu.Main;
using Random = UnityEngine.Random;
using static AetherTemp.Notifications.notif2;
using AetherTemp.Notifications;

namespace StupidTemplate.Menu
{
    public class mods : MonoBehaviour
    {
            public static void Disconnect()
        {
            PhotonNetwork.Disconnect();
            DrawNotif("You have disconnected.");
            }
        public static void DisconnectRT()
        {
            if (Main.rt > 0.5f)
            {
                PhotonNetwork.Disconnect();
            }
        }
        public static void DisconnectRG()
        {
            if (ControllerInputPoller.instance.rightGrab)
            {
                PhotonNetwork.Disconnect();
            }
        }
        public static void DisconnectRJ()
        {
            if (SteamVR_Actions.gorillaTag_RightJoystickClick.GetState(SteamVR_Input_Sources.RightHand))
            {
                PhotonNetwork.Disconnect();
            }
        }

        public static void placeholder()
        {

        }
        public static void EnableMenuText()
        {
            Settings.disableMenuText = false;
        }
        public static void DisableMenuText()
        {
            Settings.disableMenuText = true;
        }


        public static bool leftTouching = false;
        public static bool rightTouching = false;

        public static void PullMod(float power)
        {
            if (ControllerInputPoller.instance.rightGrab)
            {
                if (leftTouching && !GTPlayer.Instance.IsHandTouching(true) || rightTouching && !GTPlayer.Instance.IsHandTouching(false))
                {
                    Vector3 velocity = GTPlayer.Instance.GetComponent<Rigidbody>().velocity;
                    GTPlayer.Instance.transform.position += new Vector3(velocity.x * power, 0f, velocity.z * power);
                }
            }

            leftTouching = GTPlayer.Instance.IsHandTouching(true);
            rightTouching = GTPlayer.Instance.IsHandTouching(false);
        }
        public static void UnnoticablePullMod()
        {
            PullMod(0.035f);
        }
        public static void MidPullMod()
        {
            PullMod(0.09f);
        }
        public static void StrongPullMod()
        {
            PullMod(0.2f);
        }
        public static void changearmlength(float length)
        {
            GTPlayer.Instance.transform.localScale = new Vector3(length, length, length);
        }
        public static void fix()
        {
            changearmlength(1f);
        }
        public static void unnotic()
        {
            changearmlength(1.15f);
        }
        public static void mid()
        {
            changearmlength(1.3f);
        }
        public static void longg()
        {
            changearmlength(2f);
        }
        public static void hz()
        {
            Thread.Sleep(15);
        }
        public static GameObject bruh1;
        public static GameObject bruh2;
        public static void press()
        {
            Vector3 headPos = GorillaTagger.Instance.headCollider.transform.position;
            bruh1.transform.position = headPos - GorillaTagger.Instance.leftHandTransform.position;
            bruh2.transform.position = headPos - GorillaTagger.Instance.rightHandTransform.position;
            GTPlayer.Instance.leftControllerTransform.transform.position -= bruh1.GetComponent<GorillaVelocityTracker>().GetAverageVelocity(true, 0f, false) * 0.007f;
            GTPlayer.Instance.rightControllerTransform.transform.position -= bruh2.GetComponent<GorillaVelocityTracker>().GetAverageVelocity(true, 0f, false) * 0.007f;
        }
        public static float VelFlySpeed = 200000f;
        public static float FlySpeed = 75f;
        public static void VelocityFly()
        {
            if (ControllerInputPoller.instance.rightControllerSecondaryButton)
            {
                if (handFly)
                {
                    GTPlayer.Instance.GetComponent<Rigidbody>().AddForce(GTPlayer.Instance.rightControllerTransform.forward * VelFlySpeed * Time.deltaTime);
                }
                else
                {
                    GTPlayer.Instance.GetComponent<Rigidbody>().AddForce(GTPlayer.Instance.headCollider.transform.forward * VelFlySpeed * Time.deltaTime);
                }
            }
        }
        //100000f
        //200000f
        //500000f
        //1500000f
        public static void Fly()
        {
            if (ControllerInputPoller.instance.rightControllerSecondaryButton)
            {
                if (handFly)
                {
                    GTPlayer.Instance.transform.position += GTPlayer.Instance.rightControllerTransform.forward * Time.deltaTime * FlySpeed;
                }
                else
                {
                    GTPlayer.Instance.transform.position += GTPlayer.Instance.headCollider.transform.forward * Time.deltaTime * FlySpeed;
                }
                GTPlayer.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
            }
        }
        public static void NoclipFly()
        {
            if (ControllerInputPoller.instance.rightControllerSecondaryButton)
            {
                if (handFly)
                {
                    GTPlayer.Instance.transform.position += GTPlayer.Instance.rightControllerTransform.forward * Time.deltaTime * FlySpeed;
                }
                else
                {
                    GTPlayer.Instance.transform.position += GTPlayer.Instance.headCollider.transform.forward * Time.deltaTime * FlySpeed;
                }
                GTPlayer.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
                foreach (MeshCollider colliders in Resources.FindObjectsOfTypeAll<MeshCollider>())
                {
                    colliders.enabled = false;
                }
            }
            else
            {
                foreach (MeshCollider colliders in Resources.FindObjectsOfTypeAll<MeshCollider>())
                {
                    colliders.enabled = true;
                }
            }
        }
        //10f
        //100f
        //200f
        //75f
        public static int flyIndex = 5;
        public static int velFlyIndex = 5;
        public static bool handFly = false;
        public static void EnableHandFly()
        {
            handFly = true;
        }
        public static void DisableHandFly()
        {
            handFly = false;
        }
        public static void ChangeFlySpeed()
        {
            flyIndex++;
            if (flyIndex > 5)
            {
                flyIndex = 0;
            }
            switch (flyIndex)
            {
                case 0: FlySpeed = 10f; break;
                case 1: FlySpeed = 50f; break;
                case 2: FlySpeed = 150f; break;
                case 3: FlySpeed = 200f; break;
                case 4: FlySpeed = 1000f; break;
                case 5: FlySpeed = 75f; break;
            }
        }
        public static void ChangeVelFlySpeed()
        {
            velFlyIndex++;
            if (velFlyIndex > 5)
            {
                velFlyIndex = 0;
            }
            switch (velFlyIndex)
            {
                case 0: VelFlySpeed = 20000f; break;
                case 1: VelFlySpeed = 100000f; break;
                case 2: VelFlySpeed = 500000f; break;
                case 3: VelFlySpeed = 1500000f; break;
                case 4: VelFlySpeed = 2500000f; break;
                case 5: VelFlySpeed = 200000f; break;
            }
        }
        public static int multiIndex = 5;
        public static int speedIndex = 5;
        public static void ChangeJumpMulti()
        {
            multiIndex++;
            if (multiIndex > 5)
            {
                multiIndex = 0;
            }
            switch (multiIndex)
            {
                case 0: jumpmulti = 0.1f; break;
                case 1: jumpmulti = 1f; break;
                case 2: jumpmulti = 3f; break;
                case 3: jumpmulti = 10f; break;
                case 4: jumpmulti = 15f; break;
                case 5: jumpmulti = 1.25f; break;
            }
        }
        public static void ChangeMaxJumpSpeed()
        {
            speedIndex++;
            if (speedIndex > 5)
            {
                speedIndex = 0;
            }
            switch (speedIndex)
            {
                case 0: maxjumpsped = 1f; break;
                case 1: maxjumpsped = 2f; break;
                case 2: maxjumpsped = 3f; break;
                case 3: maxjumpsped = 5f; break;
                case 4: maxjumpsped = 20f; break;
                case 5: maxjumpsped = 8f; break;
            }
        }
        public static void FPC()
        {
            ThirdPersonCamera = GameObject.Find("Player Objects/Third Person Camera/Shoulder Camera");
            CMVirtualCamera = GameObject.Find("Player Objects/Third Person Camera/Shoulder Camera/CM vcam1");
            ThirdPersonCamera.transform.position = GTPlayer.Instance.headCollider.transform.position;
            CMVirtualCamera.transform.position = GTPlayer.Instance.headCollider.transform.position;
            ThirdPersonCamera.GetComponent<Camera>().fieldOfView = 103f;
            CMVirtualCamera.GetComponent<CinemachineVirtualCamera>().enabled = true;
        }
        public static GameObject ThirdPersonCamera;
        public static GameObject CMVirtualCamera;
        public static void ZeroGrav()
        {
            GTPlayer.Instance.bodyCollider.attachedRigidbody.useGravity = false;
        }
        public static void FixGrav()
        {
            GTPlayer.Instance.bodyCollider.attachedRigidbody.useGravity = true;
        }
        public static float maxjumpsped = 8f;
        public static float jumpmulti = 1.25f;
        public static void GripSpeedBoost()
        {
            if (ControllerInputPoller.instance.rightGrab)
            {
                GTPlayer.Instance.jumpMultiplier = jumpmulti;
                GTPlayer.Instance.maxJumpSpeed = maxjumpsped;
            }
        }
        public static void SpeedBoost()
        {
            GTPlayer.Instance.jumpMultiplier = jumpmulti;
            GTPlayer.Instance.maxJumpSpeed = maxjumpsped;
        }
        public static void CompSpeedBoost(float Intensity)
        {
            GTPlayer.Instance.jumpMultiplier = 1.25f;
            GTPlayer.Instance.maxJumpSpeed = Intensity;
        }
        public static void WeakSpeedBoost()
        {
            CompSpeedBoost(7f);
        }
        public static void DecentSpeedBoost()
        {
            CompSpeedBoost(8f);
        }
        public static void GoodSpeedBoost()
        {
            CompSpeedBoost(9f);
        }
        public static void StrongSpeedBoost()
        {
            CompSpeedBoost(11f);
        }
        public static void SuperSpeedBoost()
        {
            CompSpeedBoost(22f);
        }
        public static void CompGripSpeedBoost(float Intensity)
        {
            if (ControllerInputPoller.instance.rightGrab)
            {
                GTPlayer.Instance.jumpMultiplier = 1.25f;
                GTPlayer.Instance.maxJumpSpeed = Intensity;
            }
        }
        public static void WeakGripSpeedBoost()
        {
            CompGripSpeedBoost(7f);
        }
        public static void DecentGripSpeedBoost()
        {
            CompGripSpeedBoost(8f);
        }
        public static void GoodGripSpeedBoost()
        {
            CompGripSpeedBoost(9f);
        }
        public static void StrongGripSpeedBoost()
        {
            CompGripSpeedBoost(11f);
        }
        public static void SuperGripSpeedBoost()
        {
            CompGripSpeedBoost(22f);
        }
        private static GameObject L;
        private static GameObject R;
        public static Vector3 PlatScale = new Vector3(0.2f, 0.2f, 0.2f);
        public static bool rightspawn;
        public static bool leftspawn;
        public static void DrawRightPlat()
        {
            Color color = Color.Lerp(Color.black, Settings.buuu, Mathf.PingPong(Time.time, 1));
            R = GameObject.CreatePrimitive(PrimitiveType.Cube);
            UnityEngine.Object.Destroy(R.GetComponent<Rigidbody>());
            UnityEngine.Object.Destroy(R.GetComponent<BoxCollider>());
            UnityEngine.Object.Destroy(R.GetComponent<Renderer>());
            R.transform.localScale = PlatScale;
            GameObject gameObject = GameObject.CreatePrimitive(PrimitiveType.Cube);
            UnityEngine.Object.Destroy(gameObject.GetComponent<Rigidbody>());
            gameObject.transform.parent = R.transform;
            gameObject.transform.rotation = Quaternion.identity;
            gameObject.transform.localScale = new Vector3(0.1f, 1f, 1f);
            gameObject.GetComponent<Renderer>().material.color = color;
            gameObject.transform.position = new Vector3(-0.02f, 0f, 0f);
        }
        public static void DrawLeftPlat()
        {
            Color color = Color.Lerp(Color.black, Settings.buuu, Mathf.PingPong(Time.time, 1));
            L = GameObject.CreatePrimitive(PrimitiveType.Cube);
            UnityEngine.Object.Destroy(L.GetComponent<Rigidbody>());
            UnityEngine.Object.Destroy(L.GetComponent<BoxCollider>());
            UnityEngine.Object.Destroy(L.GetComponent<Renderer>());
            L.transform.localScale = PlatScale;
            GameObject gameObject2 = GameObject.CreatePrimitive(PrimitiveType.Cube);
            UnityEngine.Object.Destroy(gameObject2.GetComponent<Rigidbody>());
            gameObject2.transform.parent = L.transform;
            gameObject2.transform.rotation = Quaternion.identity;
            gameObject2.transform.localScale = new Vector3(0.1f, 1f, 1f);
            gameObject2.GetComponent<Renderer>().material.color = color;
            gameObject2.transform.position = new Vector3(0.02f, 0f, 0f);
        }
        public static void Platforms(bool istrigger)
        {
            bool rightGrab = ControllerInputPoller.instance.rightGrab;
            bool leftGrab = ControllerInputPoller.instance.leftGrab;
            if (istrigger)
            {
                rightGrab = Main.rt > 0.5f;
                leftGrab = Main.lt > 0.5f;
            }
            else
            {
                rightGrab = ControllerInputPoller.instance.rightGrab;
                leftGrab = ControllerInputPoller.instance.leftGrab;
            }
            if (rightGrab && R == null)
            {
                DrawRightPlat();
            }
            if (leftGrab && L == null)
            {
                DrawLeftPlat();
            }
            if (rightGrab && R != null && !rightspawn)
            {
                R.transform.position = GTPlayer.Instance.rightControllerTransform.position;
                R.transform.rotation = GTPlayer.Instance.rightControllerTransform.rotation;
                rightspawn = true;
            }
            if (leftGrab && L != null && !leftspawn)
            {
                L.transform.position = GTPlayer.Instance.leftControllerTransform.position;
                L.transform.rotation = GTPlayer.Instance.leftControllerTransform.rotation;
                leftspawn = true;
            }
            if (!rightGrab && R != null || !leftGrab && L != null)
            {
                GameObject.Destroy(R);
                R = null;
                rightspawn = false;
                GameObject.Destroy(L);
                L = null;
                leftspawn = false;
            }
        }
        public static void TagSelf()
        {
            if (Main.rt > 0.5f || Mouse.current.leftButton.isPressed)
            {
                foreach (VRRig rig in GameObject.FindObjectsOfType<VRRig>())
                {
                    if (!GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("fected"))
                    {
                        if (rig.mainSkin.material.name.Contains("fected"))
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = false;
                            GorillaTagger.Instance.offlineVRRig.transform.position = rig.rightHandTransform.position;
                            GorillaTagger.Instance.offlineVRRig.enabled = true;
                        }
                    }
                    if (GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("fected"))
                    {
                        Main.GetIndex("Tag Self [RT]").enabled = false;
                        GorillaTagger.Instance.offlineVRRig.enabled = true;
                    }
                }
            }
        }
        public static void TagGun(VRRig therig)
        {
            if (GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("fected"))
            {
                if (!therig.mainSkin.material.name.Contains("fected"))
                {
                    GorillaTagger.Instance.offlineVRRig.enabled = false;
                    GorillaTagger.Instance.offlineVRRig.transform.position = therig.bodyTransform.position + new Vector3(0f, -2f, 0f);
                    GTPlayer.Instance.leftControllerTransform.position = therig.bodyTransform.position;
                    GorillaTagger.Instance.offlineVRRig.enabled = true;
                }
            }
        }
        public static void TagAll()
        {
            if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.5f || Mouse.current.leftButton.isPressed)
            {
                foreach (VRRig rig in GameObject.FindObjectsOfType<VRRig>())
                {
                    if (GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("fected"))
                    {
                        if (rig != GorillaTagger.Instance.offlineVRRig)
                        {
                            if (!rig.mainSkin.material.name.Contains("fected"))
                            {
                                GorillaTagger.Instance.offlineVRRig.enabled = false;
                                GorillaTagger.Instance.offlineVRRig.transform.position = rig.transform.position + new Vector3(0f, -2f, 0f);
                                GTPlayer.Instance.leftControllerTransform.position = rig.transform.position;
                                GorillaTagger.Instance.offlineVRRig.enabled = true;
                            }
                        }
                    }
                }
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }
        }
        public static void TagAura()
        {
            if (ControllerInputPoller.instance.rightGrab || Mouse.current.leftButton.isPressed)
            {
                foreach (VRRig rig in GameObject.FindObjectsOfType<VRRig>())
                {
                    if (GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("fected"))
                    {
                        if (rig != GorillaTagger.Instance.offlineVRRig)
                        {
                            if (!rig.mainSkin.material.name.Contains("fected"))
                            {
                                if (Vector3.Distance(rig.transform.position, GTPlayer.Instance.transform.position) < 3f)
                                {
                                    GTPlayer.Instance.leftControllerTransform.position = rig.transform.position;
                                }
                            }
                        }
                    }
                }
            }
        }
        public static void DayTime()
        {
            BetterDayNightManager.instance.SetTimeOfDay(3);
        }
        public static void MorningTime()
        {
            BetterDayNightManager.instance.SetTimeOfDay(1);
        }
        public static void NightTime()
        {
            BetterDayNightManager.instance.SetTimeOfDay(0);
        }
        public static void EnableAllRain()
        {
            for (int i = 0; i < BetterDayNightManager.instance.weatherCycle.Length; i++)
            {
                BetterDayNightManager.instance.weatherCycle[i] = BetterDayNightManager.WeatherType.Raining;
            }
        }
        public static void DisableAllRain()
        {
            for (int i = 0; i < BetterDayNightManager.instance.weatherCycle.Length; i++)
            {
                BetterDayNightManager.instance.weatherCycle[i] = BetterDayNightManager.WeatherType.None;
            }
        }
        public static void ChamsSelf()
        {
            GorillaTagger.Instance.offlineVRRig.mainSkin.material.shader = Shader.Find("GUI/Text Shader");
            float h2 = (Time.frameCount / 80f) % 1f;
            GorillaTagger.Instance.offlineVRRig.mainSkin.material.color = Color.HSVToRGB(h2, 0.3f, 1f);
        }
        public static void Chams()
        {
            if (PhotonNetwork.CurrentRoom != null)
            {
                foreach (VRRig rig in GorillaParent.instance.vrrigs)
                {
                    if (!rig.isOfflineVRRig && !rig.isMyPlayer)
                    {
                        rig.mainSkin.material.shader = Shader.Find("GUI/Text Shader");
                        float h2 = (Time.frameCount / 80f) % 1f;
                        rig.mainSkin.material.color = Color.HSVToRGB(h2, 0.3f, 1f);
                    }
                }
            }
        }
        public static void Tracers()
        {
            if (PhotonNetwork.CurrentRoom != null)
            {
                foreach (VRRig rig in GorillaParent.instance.vrrigs)
                {
                    GameObject lines = new GameObject("Line");
                    LineRenderer lr = lines.AddComponent<LineRenderer>();
                    if (Settings.followMenuTheme)
                    {
                        lr.startColor = Color.Lerp(Color.black, buuu, Mathf.PingPong(Time.time, 1));
                        lr.endColor = Color.Lerp(Color.black, buuu, Mathf.PingPong(Time.time, 1));
                    }
                    else
                    {
                        lr.startColor = rig.mainSkin.material.color;
                        lr.endColor = rig.mainSkin.material.color;
                    }
                    lr.startWidth = 0.01f;
                    lr.endWidth = 0.01f;
                    lr.positionCount = 2;
                    lr.useWorldSpace = true;
                    lr.material.shader = Shader.Find("GUI/Text Shader");
                    lr.SetPosition(0, GTPlayer.Instance.rightControllerTransform.position);
                    lr.SetPosition(1, rig.transform.position);
                    GameObject.Destroy(lr, Time.deltaTime);
                    GameObject.Destroy(lines, Time.deltaTime);

                }
            }
        }
        public static TrailRenderer Trails;
        public static void TrailPlayers()
        {
            if (PhotonNetwork.CurrentRoom != null)
            {
                foreach (VRRig rig in GorillaParent.instance.vrrigs)
                {
                    Trails = rig.AddComponent<TrailRenderer>();
                    if (!destroyed)
                    {
                        Trails.GetComponent<TrailRenderer>().enabled = true;
                        destroyed = true;
                    }
                    if (followMenuTheme)
                    {
                        Gradient gradient = new Gradient();
                        gradient.SetKeys(
                            new GradientColorKey[]
                            {
                new GradientColorKey(buuu, 0f),
                new GradientColorKey(buuu, 0.5f),
                new GradientColorKey(Color.white, 1f)
                            }, new GradientAlphaKey[]
                            {
                new GradientAlphaKey(1f, 0f),
                new GradientAlphaKey(1f, 1f)
                            });
                        Trails.colorGradient = gradient;
                    }
                    else
                    {
                        Gradient gradient = new Gradient();
                        gradient.SetKeys(
                            new GradientColorKey[]
                            {
                new GradientColorKey( rig.mainSkin.material.color, 0f),
                new GradientColorKey(rig.mainSkin.material.color, 0.5f),
                new GradientColorKey(Color.white, 1f)
                            }, new GradientAlphaKey[]
                            {
                new GradientAlphaKey(1f, 0f),
                new GradientAlphaKey(1f, 1f)
                            });
                        Trails.colorGradient = gradient;
                    }
                    Trails.time = 1f;
                    Trails.startWidth = 0.1f;
                    Trails.endWidth = 0f;
                    Trails.material = new Material(Shader.Find("GUI/Text Shader"));

                }
            }
        }
        public static bool destroyed = true;
        public static void DestroyTrails()
        {
            foreach (VRRig rig in GorillaParent.instance.vrrigs)
            {
                destroyed = false;
                Trails.GetComponent<TrailRenderer>().enabled = false;
            }
        }
        public static int maxThemeIndex = 12;
        public static int themeIndex = maxThemeIndex;
        public static void ChangeTheme()
        {
            themeIndex++;
            if (themeIndex > maxThemeIndex)
            {
                themeIndex = 0;
            }
            switch (themeIndex)
            {
                case 0:
                    backgroundColor = Color.red;
                    buttonColors[0] = Color.red;
                    buttonColors[1] = BetterColors.dark;
                    outlineColor = BetterColors.darkRed;
                    buuu = BetterColors.dark; break;
                case 1:
                    backgroundColor = Color.green;
                    buttonColors[0] = Color.green;
                    buttonColors[1] = BetterColors.dark;
                    outlineColor = BetterColors.darkGreen;
                    buuu = BetterColors.darkGreen; break;
                case 2:
                    backgroundColor = Color.blue;
                    buttonColors[0] = Color.blue;
                    buttonColors[1] = BetterColors.dark;
                    outlineColor = BetterColors.darkBlue;
                    buuu = BetterColors.darkBlue; break;
                case 3:
                    backgroundColor = BetterColors.cyan2;
                    buttonColors[0] = Color.cyan;
                    buttonColors[1] = BetterColors.dark;
                    outlineColor = BetterColors.darkCyan;
                    buuu = BetterColors.darkCyan; break;
                case 4:
                    backgroundColor = BetterColors.dark;
                    buttonColors[0] = BetterColors.lightPurple;
                    buttonColors[1] = BetterColors.black;
                    outlineColor = BetterColors.lightPurple;
                    buuu = BetterColors.lightPurple; break;
                case 5:
                    backgroundColor = BetterColors.dark;
                    buttonColors[0] = BetterColors.darkGrey;
                    buttonColors[1] = BetterColors.dark;
                    outlineColor = BetterColors.ogComicColor;
                    buuu = BetterColors.ogComicColor; break;
                case 6:
                    backgroundColor = BetterColors.lightPink;
                    buttonColors[0] = BetterColors.pink;
                    buttonColors[1] = BetterColors.lightPink;
                    outlineColor = BetterColors.pink;
                    buuu = BetterColors.lightPink; break;
                case 7:
                    backgroundColor = BetterColors.pink;
                    buttonColors[0] = BetterColors.lightPink;
                    buttonColors[1] = BetterColors.pink;
                    outlineColor = BetterColors.lightPink;
                    buuu = BetterColors.pink; break;
                case 8:
                    backgroundColor = BetterColors.iidkColor;
                    buttonColors[0] = BetterColors.iidkColorButtonDis;
                    buttonColors[1] = BetterColors.iidkColorButton;
                    outlineColor = BetterColors.iidkColorButton;
                    buuu = BetterColors.iidkColor; break;
                case 9:
                    backgroundColor = Color.HSVToRGB(0.12f, 0.12f, 0.12f);
                    buttonColors[0] = Color.HSVToRGB(0.12f, 0.12f, 0.12f);
                    buttonColors[1] = BetterColors.black;
                    outlineColor = BetterColors.black;
                    buuu = Color.HSVToRGB(0.12f, 0.12f, 0.12f); break;
                case 10:
                    backgroundColor = BetterColors.dark;
                    buttonColors[0] = BetterColors.darkGrey;
                    buttonColors[1] = BetterColors.lightPurple;
                    outlineColor = BetterColors.lightPurple;
                    buuu = BetterColors.lightPurple; break;
                case 11:
                    backgroundColor = BetterColors.hotPink;
                    buttonColors[0] = BetterColors.pink;
                    buttonColors[1] = BetterColors.hotPink;
                    outlineColor = BetterColors.pink;
                    buuu = BetterColors.hotPink; break;
                case 12:
                    backgroundColor = BetterColors.dark;
                    buttonColors[0] = BetterColors.darkGrey;
                    buttonColors[1] = BetterColors.dark;
                    outlineColor = BetterColors.darkGrey;
                    buuu = BetterColors.darkGrey; break;
            }
            Main.RecreateMenu();
        }
        #region idk
        public static void FollowTheme()
        {
            followMenuTheme = true;
        }
        public static void DontFollowTheme()
        {
            followMenuTheme = false;
        }
        public static void EnablePageButtons()
        {
            pageButtons = true;
        }
        public static void DisablePageButtons()
        {
            pageButtons = false;
        }
        public static void EnableRound()
        {
            roundMenu = true;
        }
        public static void DisableRound()
        {
            roundMenu = false;
        }
        public static void EnableOutlines()
        {
            outlineMenu = true;
        }
        public static void DisableOutlines()
        {
            outlineMenu = false;
        }
        public static void EnableOrbitSphere()
        {
            orbitSphere = true;
        }
        public static void DisableOrbitSphere()
        {
            orbitSphere = false;
        }
        public static void EnableAnimatingText()
        {
            animtaingText = true;
        }
        public static void DisableAnimatingText()
        {
            animtaingText = false;
        }
        #endregion
        public static void Noclip()
        {
            if (Main.rt > 0.5f || Mouse.current.leftButton.isPressed)
            {
                foreach (MeshCollider colliders in Resources.FindObjectsOfTypeAll<MeshCollider>())
                {
                    colliders.enabled = false;
                }
            }
            else
            {
                foreach (MeshCollider colliders in Resources.FindObjectsOfTypeAll<MeshCollider>())
                {
                    colliders.enabled = true;
                }
            }
        }
        public static void EnableMeshColliders()
        {
            foreach (MeshCollider colliders in Resources.FindObjectsOfTypeAll<MeshCollider>())
            {
                colliders.enabled = true;
            }
        }
        public static void TPGun()
        {
            if (Main.rt > 0.5f || Mouse.current.leftButton.isPressed)
            {
                if (antirepeat)
                {
                    GTPlayer.Instance.transform.position = GunSphere.transform.position;
                    antirepeat = false;
                }
            }
            else
            {
                antirepeat = true;
            }
        }
        public static void RigGun()
        {
            if (Main.rt > 0.5f || Mouse.current.leftButton.isPressed)
            {
                GorillaTagger.Instance.offlineVRRig.enabled = false;
                GorillaTagger.Instance.offlineVRRig.transform.position = GunSphere.transform.position;
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }
        }
        public static void DisableNetworkTriggers()
        {
            GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab").SetActive(false);
        }
        public static void EnableNetworkTriggers()
        {
            GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab").SetActive(true);
        }
        public static bool antirepeat;
        public static GameObject GunSphere;
        private static Vector3 GunSphereSmooth = Vector3.zero;
        private static LineRenderer lineRenderer;
        private static float timeCounter = 0f;
        private static Vector3[] linePositions;
        private static Vector3 previousControllerPosition;
        public static float num = 10f;
        public static void GunSmoothNess()
        {
            if (num == 10f)
                num = 15f;  // Super smooth (slower)
            else if (num == 15f)
                num = 100f;   // Fast (no smoothness)
            else
                num = 10f;  // Normal smoothness
        }

        public static bool isSphereEnabled = true;


        public static VRRig lockedVRRig;
        public static GameObject gunPointer;
        public static TrailRenderer Trail;
        public static bool didLock = false;
        public static void GunTemplate(Action act, bool wannalock)
        {
            if (ControllerInputPoller.instance.rightControllerGripFloat > 0.1f || UnityInput.Current.GetMouseButton(1))
            {
                if (Physics.Raycast(GTPlayer.Instance.rightControllerTransform.position, -GTPlayer.Instance.rightControllerTransform.up, out var hitinfo))
                {
                    int i;
                    if (Mouse.current.rightButton.isPressed)
                    {
                        Camera cam = GameObject.Find("Shoulder Camera").GetComponent<Camera>();
                        Ray ray = cam.ScreenPointToRay(Mouse.current.position.ReadValue());
                        Physics.Raycast(ray, out hitinfo, 100);
                    }

                    if (GunSphere == null)
                    {
                        GunSphere = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        GunSphere.transform.localScale = isSphereEnabled ? new Vector3(0.2f, 0.2f, 0.2f) : new Vector3(0f, 0f, 0f);
                        GunSphere.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
                        GunSphere.GetComponent<Renderer>().material.color = buuu;

                        GameObject.Destroy(GunSphere.GetComponent<BoxCollider>());
                        GameObject.Destroy(GunSphere.GetComponent<Rigidbody>());
                        GameObject.Destroy(GunSphere.GetComponent<Collider>());
                        Trail = GunSphere.AddComponent<TrailRenderer>();
                        Gradient gradient = new Gradient();
                        gradient.SetKeys(
                            new GradientColorKey[]
                            {
                new GradientColorKey(buuu, 0f),
                new GradientColorKey(buuu, 0.5f),
                new GradientColorKey(Color.white, 1f)
                            }, new GradientAlphaKey[]
                            {
                new GradientAlphaKey(1f, 0f),
                new GradientAlphaKey(1f, 1f)
                            });
                        Trail.colorGradient = gradient;
                        Trail.time = 1f;
                        Trail.startWidth = 0.1f;
                        Trail.endWidth = 0f;
                        Trail.material = new Material(Shader.Find("Sprites/Default"));
                        lineRenderer = GunSphere.AddComponent<LineRenderer>();
                        lineRenderer.material = new Material(Shader.Find("Sprites/Default"));
                        lineRenderer.widthCurve = AnimationCurve.Linear(0, 0.01f, 1, 0.01f);
                        Gradient gradient2 = new Gradient();
                        gradient2.SetKeys(
                            new GradientColorKey[]
                            {
                new GradientColorKey(buuu, 0f),
                new GradientColorKey(buuu, 0.5f),
                new GradientColorKey(Color.white, 1f)
                            }, new GradientAlphaKey[]
                            {
                new GradientAlphaKey(1f, 0f),
                new GradientAlphaKey(1f, 1f)
                            });
                        lineRenderer.colorGradient = gradient2;
                        linePositions = new Vector3[50];
                        for (i = 0; i < linePositions.Length; i++)
                        {
                            linePositions[i] = GTPlayer.Instance.rightControllerTransform.position;
                        }
                        GameObject sphere = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        sphere.transform.parent = lineRenderer.transform;
                        sphere.transform.localScale = new Vector3(0.3f, 0.3f, 0.3f);
                        sphere.GetComponent<Renderer>().material.color = buuu;
                        GameObject.Destroy(sphere.GetComponent<Collider>());
                        sphere.AddComponent<thspherethatorbnits>();
                    }

                    GunSphere.transform.position = hitinfo.point;

                    timeCounter += Time.deltaTime;

                    Vector3 pos1 = GTPlayer.Instance.rightControllerTransform.position;
                    Vector3 direction = (hitinfo.point - pos1).normalized;
                    float distance = Vector3.Distance(pos1, hitinfo.point);

                    Vector3 controller = pos1 - previousControllerPosition;
                    previousControllerPosition = pos1;

                    if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f || Mouse.current.leftButton.isPressed)
                    {
                        if (wannalock)
                        {
                            if (hitinfo.collider.GetComponentInParent<VRRig>() != null)
                            {
                                lockedVRRig = hitinfo.collider.GetComponentInParent<VRRig>();
                                didLock = true;
                            }

                            if (!lockedVRRig.isLocal && didLock == true)
                            {
                                GunSphere.transform.position = lockedVRRig.transform.position;
                                lineRenderer.transform.position = lockedVRRig.transform.position;
                                act();
                            }
                        }
                        else
                        {
                            act();
                        }

                    }

                    for (i = 0; i < linePositions.Length; i++)
                    {
                        float t = i / (float)(linePositions.Length - 1);
                        Vector3 linePos = Vector3.Lerp(pos1, hitinfo.point, t);

                        linePositions[i] += controller * 0.2f;//0.5f
                        linePositions[i] += UnityEngine.Random.insideUnitSphere * 0.05f;//0.01f
                        linePositions[i] = Vector3.Lerp(linePositions[i], linePos, Time.deltaTime * num);
                    }

                    lineRenderer.positionCount = linePositions.Length;
                    lineRenderer.SetPositions(linePositions);
                    GunSphere.GetComponent<Renderer>().material.color = buuu;
                    lineRenderer.startColor = buuu;
                    lineRenderer.endColor = buuu;
                }
            }

            if (GunSphere != null && (ControllerInputPoller.instance.rightControllerGripFloat <= 0.1f && !UnityInput.Current.GetMouseButton(1)))
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
                GameObject.Destroy(GunSphere);
                GameObject.Destroy(lineRenderer);
                GameObject.Destroy(Trail);
                timeCounter = 0f;
                linePositions = null;
            }
        }


        public static void ChatGPTESP()
        {
            Shader guiShader = Shader.Find("GUI/Text Shader");
            Material baseMat = new Material(guiShader);
            baseMat.SetInt("_ZTest", (int)UnityEngine.Rendering.CompareFunction.Always);

            foreach (VRRig rig in GorillaParent.instance.vrrigs)
            {
                if (rig.bodyTransform.Find("SpaceESP_Torus") != null)
                    continue;
                if (rig.bodyTransform.Find("SpaceESP_Torus2") != null)
                    continue;
                if (rig == null || rig.bodyTransform == null) continue;
                Vector3 basePos = rig.bodyTransform.position;
                Color RingColor;
                    RingColor = buuu;
                GameObject torus = new GameObject("SpaceESP_Torus");
                torus.transform.position = basePos + new Vector3(0, 0.2f, 0);
                torus.transform.rotation = Quaternion.Euler(30f, 0, 0);
                torus.transform.localScale = Vector3.one * 0.4f;

                MeshFilter mf = torus.AddComponent<MeshFilter>();
                MeshRenderer mr = torus.AddComponent<MeshRenderer>();
                mf.mesh = GenerateTorusMesh(0.02f, 0.8f, 20, 14);
                Material torusMat = new Material(baseMat);
                torusMat.color = RingColor;
                mr.material = torusMat;
                torus.AddComponent<Rotator>().rotationSpeed = 80f;


                GameObject pivot = new GameObject("SpaceESP_Pivot");
                pivot.transform.position = basePos;

                GameObject torus2 = new GameObject("SpaceESP_Torus2");
                torus2.transform.position = basePos + new Vector3(0, 0.2f, 0);
                torus2.transform.rotation = Quaternion.Euler(-30f, 0, 0);
                torus2.transform.localScale = Vector3.one * 0.4f;

                MeshFilter mf2 = torus2.AddComponent<MeshFilter>();
                MeshRenderer mr2 = torus2.AddComponent<MeshRenderer>();
                mf2.mesh = GenerateTorusMesh(0.02f, 0.9f, 20, 14);
                Material torusMat2 = new Material(baseMat);
                torusMat2.color = RingColor;
                mr2.material = torusMat2;
                torus2.AddComponent<Rotator>().rotationSpeed = 120f;
                GameObject pivot2 = new GameObject("SpaceESP_Pivot2");
                pivot2.transform.position = basePos;
                for (int i = 0; i < 3; i++)
                {
                    GameObject star = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    Destroy(star.GetComponent<Collider>());

                    Vector3 offset = Quaternion.Euler(0, i * 120f, 0) * Vector3.right * 0.3f;
                    star.transform.position = basePos + offset;
                    star.transform.localScale = Vector3.one * 0.05f;
                    star.transform.SetParent(pivot.transform, true);

                    Material starMat = new Material(baseMat);
                        starMat.color = buuu;
                    star.GetComponent<Renderer>().material = starMat;
                    star.name = "SpaceESP_Star";
                }
                torus.transform.SetParent(rig.bodyTransform);
                pivot.transform.SetParent(rig.bodyTransform);
                torus2.transform.SetParent(rig.bodyTransform);
                pivot2.transform.SetParent(rig.bodyTransform);
                pivot.AddComponent<Rotator>().rotationSpeed = 50f;
                pivot2.AddComponent<Rotator>().rotationSpeed = 100f;
            }
        }
        public static void ClearAllESP()
        {
            foreach (VRRig rig in GorillaParent.instance.vrrigs)
            {
                //if (rig == null || rig.bodyTransform == null) continue;

                GameObject esp = GameObject.Find("SpaceESP_Torus");
                esp.SetActive(false);

                GameObject esp2 = GameObject.Find("SpaceESP_Torus2");
                esp2.SetActive(false);

                GameObject pivot = GameObject.Find("SpaceESP_Pivot");
                pivot.SetActive(false);

                GameObject pivot2 = GameObject.Find("SpaceESP_Pivot2");
                pivot2.SetActive(false);
            }
        }
        private static Mesh GenerateTorusMesh(float tubeRadius, float ringRadius, int tubeSegments, int ringSegments)
        {
            List<Vector3> vertices = new List<Vector3>();
            List<Vector3> normals = new List<Vector3>();
            List<Vector2> uvs = new List<Vector2>();
            List<int> triangles = new List<int>();

            for (int i = 0; i <= ringSegments; i++)
            {
                float ringAngle = (float)i / ringSegments * Mathf.PI * 2;
                Vector3 ringCenter = new Vector3(Mathf.Cos(ringAngle), 0, Mathf.Sin(ringAngle)) * ringRadius;

                for (int j = 0; j <= tubeSegments; j++)
                {
                    float tubeAngle = (float)j / tubeSegments * Mathf.PI * 2;
                    Vector3 normal = new Vector3(Mathf.Cos(tubeAngle) * Mathf.Cos(ringAngle), Mathf.Sin(tubeAngle), Mathf.Cos(tubeAngle) * Mathf.Sin(ringAngle));
                    Vector3 vertex = ringCenter + normal * tubeRadius;

                    vertices.Add(vertex);
                    normals.Add(normal);
                    uvs.Add(new Vector2((float)i / ringSegments, (float)j / tubeSegments));
                }
            }

            int vertsPerRing = tubeSegments + 1;
            for (int i = 0; i < ringSegments; i++)
            {
                for (int j = 0; j < tubeSegments; j++)
                {
                    int a = i * vertsPerRing + j;
                    int b = (i + 1) * vertsPerRing + j;
                    int c = (i + 1) * vertsPerRing + j + 1;
                    int d = i * vertsPerRing + j + 1;

                    triangles.Add(a); triangles.Add(b); triangles.Add(c);
                    triangles.Add(a); triangles.Add(c); triangles.Add(d);
                }
            }

            Mesh mesh = new Mesh();
            mesh.SetVertices(vertices);
            mesh.SetNormals(normals);
            mesh.SetUVs(0, uvs);
            mesh.SetTriangles(triangles, 0);
            mesh.RecalculateBounds();
            return mesh;
        }

        // Minimal rotation behavior (no MonoBehaviour needed if run via your own update loop)
        public static Dictionary<string, GameObject> vrRigBoxes = new Dictionary<string, GameObject>();
        public class Rotator : MonoBehaviour
        {
            public Vector3 rotationAxis = Vector3.up;
            public float rotationSpeed = 300f;

            void Update()
            {
                transform.Rotate(rotationAxis, rotationSpeed * Time.deltaTime, Space.Self);
            }
        }
    }
}
