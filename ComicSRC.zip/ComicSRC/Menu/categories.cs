﻿using static StupidTemplate.Menu.Main;
using static StupidTemplate.Settings;

namespace AetherTemp.Menu
{
    internal class SettingsMods
    {
        public static void EnterSettings()
        {
            buttonsType = 0;
            pageNumber = 0;
        }

        public static void MainSettings()
        {
            buttonsType = 1;
            pageNumber = 0;
        }

      
        public static void GunLib()
        {
            buttonsType = 2;
            pageNumber = 0;
        }

        public static void MenuSettings()
        {
            buttonsType = 3;
            pageNumber = 0;
        }

        public static void Notification()
        {
            buttonsType = 4;
            pageNumber = 0;
        }
        public static void SwitchPage(int Type)
        {
            buttonsType = Type;
            pageNumber = 0;
        }
        public static void ProjectileSettings()
        {
            buttonsType = 12;
            pageNumber = 0;
        }

        public static void Projectiles()
        {
            buttonsType = 13;
            pageNumber = 0;
        }

        public static void Particles()
        {
            buttonsType = 14;
            pageNumber = 0;
        }



        public static void RightHand()
        {
            rightHanded = true;
        }

        public static void LeftHand()
        {
            rightHanded = false;
        }

        public static void EnableFPSCounter()
        {
            fpsCounter = true;
        }

        public static void DisableFPSCounter()
        {
            fpsCounter = false;
        }

        public static void EnableNotifications()
        {
            disableNotifications = false;
        }

        public static void DisableNotifications()
        {
            disableNotifications = true;
        }

        public static void EnableDisconnectButton()
        {
            disconnectButton = true;
        }

        public static void DisableDisconnectButton()
        {
            disconnectButton = false;
        }
    }
}
