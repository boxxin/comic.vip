![Mod Menu Banner](https://media.discordapp.net/attachments/1345742664355680547/1354189167726428465/image.png?ex=67e46271&is=67e310f1&hm=87739f0f89337d80849e9910a4ae52e0ea251b536a0b3d5ffac2397459797ac6&=&format=webp&quality=lossless)  

## Aether MiniPad Template

## 💡 Suggestions  
If you’d like me to create more templates, let me know!  
Join our **Discord server** and drop your suggestions:  
👉 [Join Here](https://discord.gg/KXABTbrQx2)  

## 📜 Disclaimer  
This is for **educational purposes only**. I am not responsible for how this is used.  

This is also my first ever template i made about a few months ago

## ❤️ Credits  
Credits to **iidk** for the main template it made it easier to create menus with it.  
*(Also please make me an actual mod creator in your server)*  

**https://discord.gg/KXABTbrQx2**
