﻿namespace StupidTemplate
{
    internal class PluginInfo
    {
        public const string GUID = "org.boxxin.gorillatag.comic";
        public const string Name = "comic.vip";
        public const string Description = "Created by @box.xin with love <3";
        public const string Version = "1.0.0";
    }
}
