﻿using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

namespace AetherTemp.Classes
{
    public class BetterColors
    {
        public static Color white = Color.white;
        public static Color black = Color.black;
        public static Color red = Color.red;
        public static Color green = Color.green;
        public static Color blue = Color.blue;
        public static Color yellow = Color.yellow;
        public static Color cyan = Color.cyan;
        public static Color magenta = Color.magenta;
        public static Color gray = Color.gray;
        public static Color grey = Color.grey;
        public static Color32 dark = new Color32(10, 10, 10, 255);
        public static Color32 darkGrey = new Color32(30, 30, 30, 255);
    }
}
