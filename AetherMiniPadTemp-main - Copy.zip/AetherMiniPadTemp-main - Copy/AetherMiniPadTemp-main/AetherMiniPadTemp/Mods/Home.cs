﻿using Photon.Pun;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Text;
using UnityEngine;
using Debug = UnityEngine.Debug;

namespace AetherTemp.Mods
{
    internal class Home
    {
        public static void JoinDiscord()
        {
            Application.OpenURL("https://discord.gg/UVbYWf8Csn");
        }
        public static void SavePrefs()
        {
            Application.OpenURL("https://discord.gg/UVbYWf8Csn");
        }
        public static void LoadPrefs()
        {
            Application.OpenURL("https://discord.gg/UVbYWf8Csn");
        }
        public static void AntiRPC()
        {
            var Grolla = GorillaNot.instance;
            Grolla.rpcErrorMax = int.MaxValue;
            Grolla.rpcCallLimit = int.MaxValue;
            Grolla.OnPlayerLeftRoom(PhotonNetwork.LocalPlayer);
            PhotonNetwork.OpCleanActorRpcBuffer(int.MaxValue);
            PhotonNetwork.RemoveRPCsInGroup(int.MaxValue);
            PhotonNetwork.RemoveRPCs(PhotonNetwork.LocalPlayer);
            PhotonNetwork.OpRemoveCompleteCache();
            PhotonNetwork.SendAllOutgoingCommands();
        }
        public static void GetAllRPCS()
        {
            string bar = "RPC's";
            int num = 0;
            foreach (string rpclist in PhotonNetwork.PhotonServerSettings.RpcList)
            {
                try
                {
                    bar += "\n--------------------------\n";
                    bar = bar + num.ToString() + rpclist;
                }
                catch { }
                num++;
            }
            bar += "\n--------------------------\n";
            File.WriteAllText("comic/RPCs.txt", bar);
            string path = Path.Combine(Assembly.GetExecutingAssembly().Location, "comic/RPCs.txt");
            path = path.Split("BepInEx\\", 0)[0] + "comic/RPCs.txt";
        }
        public static void RemoveFingerMovement()
        {
            var c = ControllerInputPoller.instance;
            c.rightControllerPrimaryButton = false;
            c.leftControllerPrimaryButton = false;
            c.rightControllerSecondaryButton = false;
            c.leftControllerSecondaryButton = false;
            c.rightControllerPrimaryButtonTouch = false;
            c.leftControllerPrimaryButtonTouch = false;
            c.rightControllerSecondaryButtonTouch = false;
            c.leftControllerSecondaryButtonTouch = false;
            c.rightGrab = false;
            c.leftGrab = false;
            c.rightControllerIndexTouch = 0f;
            c.leftControllerIndexTouch = 0f;
        }
    }
}
