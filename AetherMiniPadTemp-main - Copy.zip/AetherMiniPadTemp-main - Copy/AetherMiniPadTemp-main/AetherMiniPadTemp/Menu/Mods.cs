﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BepInEx;
using GorillaNetworking;
using Photon.Pun;
using UnityEngine;
using TMPro;
using UnityEngine.InputSystem;
using StupidTemplate.Notifications;
using ExitGames.Client.Photon;
using Photon.Realtime;
using HarmonyLib;
using AetherTemp.Menu;
using System.Text.RegularExpressions;
using StupidTemplate.Patches;
using System.Reflection;
using System.Net;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Buffers.Text;
using Valve.VR;
using GorillaTagScripts;
using System.Threading;
using StupidTemplate.Mods;
using System.Drawing;
using Color = UnityEngine.Color;
using GorillaLocomotion.Climbing;
using GorillaLocomotion;
using StupidTemplate.Classes;

namespace StupidTemplate.Menu
{
    public class mods
    {
        public static void Disconnect()
        {
            PhotonNetwork.Disconnect();
        }
        public static void DisconnectRT()
        {
            if (Main.rt > 0.5f)
            {
                PhotonNetwork.Disconnect();
            }
        }
        public static void DisconnectRG()
        {
            if (ControllerInputPoller.instance.rightGrab)
            {
                PhotonNetwork.Disconnect();
            }
        }
        public static void DisconnectRJ()
        {
            if (SteamVR_Actions.gorillaTag_RightJoystickClick.GetState(SteamVR_Input_Sources.RightHand))
            {
                PhotonNetwork.Disconnect();
            }
        }

        public static void placeholder()
        {

        }
        public static void EnableMenuText()
        {
            Settings.disableMenuText = false;
        }
        public static void DisableMenuText()
        {
            Settings.disableMenuText = true;
        }


        public static bool leftTouching = false;
        public static bool rightTouching = false;

        public static void PullMod(float power)
        {
            if (ControllerInputPoller.instance.rightGrab && leftTouching && !GTPlayer.Instance.IsHandTouching(true) || rightTouching && !GTPlayer.Instance.IsHandTouching(false))
            {
                Vector3 velocity = GTPlayer.Instance.GetComponent<Rigidbody>().velocity;
                GTPlayer.Instance.transform.position += new Vector3(velocity.x * power, 0f, velocity.z * power);
            }

            leftTouching = GTPlayer.Instance.IsHandTouching(true);
            rightTouching = GTPlayer.Instance.IsHandTouching(false);
        }
        public static void UnnoticablePullMod()
        {
            PullMod(0.035f);
        }
        public static void MidPullMod()
        {
            PullMod(0.09f);
        }
        public static void StrongPullMod()
        {
            PullMod(0.2f);
        }
        public static void changearmlength(float length)
        {
            GTPlayer.Instance.transform.localScale = new Vector3(length, length, length);
        }
        public static void fix()
        {
            changearmlength(1f);
        }
        public static void unnotic()
        {
            changearmlength(1.15f);
        }
        public static void mid()
        {
            changearmlength(1.3f);
        }
        public static void longg()
        {
            changearmlength(2f);
        }
        public static void hz()
        {
            Thread.Sleep(15);
        }
        public static GameObject bruh1;
        public static GameObject bruh2;
        public static void press()
        {
            bruh1.transform.position = GorillaTagger.Instance.headCollider.transform.position - GorillaTagger.Instance.leftHandTransform.position;
            bruh2.transform.position = GorillaTagger.Instance.headCollider.transform.position - GorillaTagger.Instance.rightHandTransform.position;
            GTPlayer.Instance.leftControllerTransform.transform.position -= bruh1.GetComponent<GorillaVelocityTracker>().GetAverageVelocity(true, 0f, false) * (2f / 333f);
            GTPlayer.Instance.rightControllerTransform.transform.position -= bruh2.GetComponent<GorillaVelocityTracker>().GetAverageVelocity(true, 0f, false) * (2f / 333f);
        }
        public static void EnableTrail(bool enable)
        {
            if (Main.trailObject != null)
            {
                Main.trailObject.SetActive(enable);
            }
        }

        public static void VelocityFly(float Speed)
        {
            if (ControllerInputPoller.instance.rightControllerSecondaryButton)
            {
                GTPlayer.Instance.GetComponent<Rigidbody>().AddForce(GTPlayer.Instance.headCollider.transform.forward * Speed * Time.deltaTime);
            }
        }
        public static void SlowVelocityFly()
        {
            VelocityFly(100000f);
        }
        public static void NormalVelocityFly()
        {
            VelocityFly(200000f);
        }
        public static void FastVelocityFly()
        {
            VelocityFly(500000f);
        }
        public static void SuperVelocityFly()
        {
            VelocityFly(1500000f);
        }
        public static void Fly(float Speed)
        {
            if (ControllerInputPoller.instance.rightControllerSecondaryButton)
            {
                GTPlayer.Instance.transform.position += GTPlayer.Instance.headCollider.transform.forward * Time.deltaTime * Speed;
                GTPlayer.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
            }
        }
        public static void SlowFly()
        {
            Fly(10f);
        }
        public static void NormalFly()
        {
            Fly(75f);
        }
        public static void FastFly()
        {
            Fly(100f);
        }
        public static void SuperFly()
        {
            Fly(200f);
        }
        public static void SpeedBoost(float Intensity)
        {
            GTPlayer.Instance.jumpMultiplier = 1.25f;
            GTPlayer.Instance.maxJumpSpeed = Intensity;
        }
        public static void WeakSpeedBoost()
        {
            SpeedBoost(7f);
        }
        public static void DecentSpeedBoost()
        {
            SpeedBoost(8f);
        }
        public static void GoodSpeedBoost()
        {
            SpeedBoost(9f);
        }
        public static void StrongSpeedBoost()
        {
            SpeedBoost(11f);
        }
        public static void SuperSpeedBoost()
        {
            SpeedBoost(22f);
        }
        public static void GripSpeedBoost(float Intensity)
        {
            if (ControllerInputPoller.instance.rightGrab)
            {
                GTPlayer.Instance.jumpMultiplier = 1.25f;
                GTPlayer.Instance.maxJumpSpeed = Intensity;
            }
        }
        public static void WeakGripSpeedBoost()
        {
            GripSpeedBoost(7f);
        }
        public static void DecentGripSpeedBoost()
        {
            GripSpeedBoost(8f);
        }
        public static void GoodGripSpeedBoost()
        {
            GripSpeedBoost(9f);
        }
        public static void StrongGripSpeedBoost()
        {
            GripSpeedBoost(11f);
        }
        public static void SuperGripSpeedBoost()
        {
            GripSpeedBoost(22f);
        }
        private static GameObject L;
        private static GameObject R;
        public static Vector3 PlatScale = new Vector3(0.2f, 0.2f, 0.2f);
        public static bool rightspawn;
        public static bool leftspawn;
        public static void DrawRightPlat()
        {
            Color color = Color.Lerp(Color.black, Settings.buuu, Mathf.PingPong(Time.time, 1));
            R = GameObject.CreatePrimitive(PrimitiveType.Cube);
            UnityEngine.Object.Destroy(R.GetComponent<Rigidbody>());
            UnityEngine.Object.Destroy(R.GetComponent<BoxCollider>());
            UnityEngine.Object.Destroy(R.GetComponent<Renderer>());
            R.transform.localScale = PlatScale;
            GameObject gameObject = GameObject.CreatePrimitive(PrimitiveType.Cube);
            UnityEngine.Object.Destroy(gameObject.GetComponent<Rigidbody>());
            gameObject.transform.parent = R.transform;
            gameObject.transform.rotation = Quaternion.identity;
            gameObject.transform.localScale = new Vector3(0.1f, 1f, 1f);
            gameObject.GetComponent<Renderer>().material.color = color;
            gameObject.transform.position = new Vector3(-0.02f, 0f, 0f);
        }
        public static void DrawLeftPlat()
        {
            Color color = Color.Lerp(Color.black, Settings.buuu, Mathf.PingPong(Time.time, 1));
            L = GameObject.CreatePrimitive(PrimitiveType.Cube);
            UnityEngine.Object.Destroy(L.GetComponent<Rigidbody>());
            UnityEngine.Object.Destroy(L.GetComponent<BoxCollider>());
            UnityEngine.Object.Destroy(L.GetComponent<Renderer>());
            L.transform.localScale = PlatScale;
            GameObject gameObject2 = GameObject.CreatePrimitive(PrimitiveType.Cube);
            UnityEngine.Object.Destroy(gameObject2.GetComponent<Rigidbody>());
            gameObject2.transform.parent = L.transform;
            gameObject2.transform.rotation = Quaternion.identity;
            gameObject2.transform.localScale = new Vector3(0.1f, 1f, 1f);
            gameObject2.GetComponent<Renderer>().material.color = color;
            gameObject2.transform.position = new Vector3(0.02f, 0f, 0f);
        }
        public static void Platforms(bool istrigger)
        {
            bool rightGrab = ControllerInputPoller.instance.rightGrab;
            bool leftGrab = ControllerInputPoller.instance.leftGrab;
            if (istrigger)
            {
                rightGrab = Main.rt > 0.5f;
                leftGrab = Main.lt > 0.5f;
            }
            else
            {
                rightGrab = ControllerInputPoller.instance.rightGrab;
                leftGrab = ControllerInputPoller.instance.leftGrab;
            }
            if (rightGrab && R == null)
            {
                DrawRightPlat();
            }
            if (leftGrab && L == null)
            {
                DrawLeftPlat();
            }
            if (rightGrab && R != null && !rightspawn)
            {
                R.transform.position = GTPlayer.Instance.rightControllerTransform.position;
                R.transform.rotation = GTPlayer.Instance.rightControllerTransform.rotation;
                rightspawn = true;
            }
            if (leftGrab && L != null && !leftspawn)
            {
                L.transform.position = GTPlayer.Instance.leftControllerTransform.position;
                L.transform.rotation = GTPlayer.Instance.leftControllerTransform.rotation;
                leftspawn = true;
            }
            if (!rightGrab && R != null || !leftGrab && L != null)
            {
                GameObject.Destroy(R);
                R = null;
                rightspawn = false;
                GameObject.Destroy(L);
                L = null;
                leftspawn = false;
            }
        }
        public static GameObject GunSphere;
        private static LineRenderer lineRenderer;
        private static float timeCounter = 0f;
        private static Vector3[] linePositions;
        private static Vector3 previousControllerPosition;
        public static float num = 10f;
        public static void GunSmoothNess()
        {
            if (num == 10f)
                num = 15f;  // Super smooth (slower)
            else if (num == 15f)
                num = 5f;   // Fast (no smoothness)
            else
                num = 10f;  // Normal smoothness
        }

        // List of colors to cycle through
        public static List<(Color color, string name)> colorCycle = new List<(Color, string)>
{
    (new Color(189f / 255f, 251f / 255f, 204f / 255f), "mint"),
    (new Color(255f / 255f, 229f / 255f, 180f / 255f), "peach"),
    (new Color(134f / 255f, 169f / 255f, 188f / 255f), "dustyBlue"),
    (new Color(200f / 255f, 162f / 255f, 200f / 255f), "lilac"),
    (new Color(255f / 255f, 255f / 255f, 204f / 255f), "paleYellow"),
    (new Color(255f / 255f, 182f / 255f, 193f / 255f), "softPink"),
    (new Color(230f / 255f, 230f / 255f, 250f / 255f), "lavender"),
    (new Color(211f / 255f, 211f / 255f, 211f / 255f), "lightGray"),
    (new Color(169f / 255f, 169f / 255f, 169f / 255f), "warmGray"),
    (new Color(255f / 255f, 255f / 255f, 240f / 255f), "ivory"),
    (new Color(245f / 255f, 240f / 255f, 195f / 255f), "beige"),
    (new Color(128f / 255f, 128f / 255f, 0f / 255f), "olive"),
    (new Color(210f / 255f, 180f / 255f, 140f / 255f), "tan"),
    (new Color(133f / 255f, 153f / 255f, 56f / 255f), "mossGreen"),
    (new Color(194f / 255f, 178f / 255f, 128f / 255f), "sand"),
    (new Color(176f / 255f, 153f / 255f, 128f / 255f), "maincolor")
};

        public static (Color color, string name) currentGunColor = colorCycle[0];

        // Method to cycle through the colors
        public static void CycleGunColor()
        {
            int currentIndex = colorCycle.IndexOf(currentGunColor);
            currentGunColor = colorCycle[(currentIndex + 1) % colorCycle.Count];  // Move to the next color
        }

        public static bool isSphereEnabled = true;


        public static void GunTemplate(Action act)
        {
            if (ControllerInputPoller.instance.rightControllerGripFloat > 0.1f || UnityInput.Current.GetMouseButton(1))
            {
                if (Physics.Raycast(GorillaLocomotion.GTPlayer.Instance.rightControllerTransform.position, -GorillaLocomotion.GTPlayer.Instance.rightControllerTransform.up, out var hitinfo))
                {
                    if (Mouse.current.rightButton.isPressed)
                    {
                        Camera cam = GameObject.Find("Shoulder Camera").GetComponent<Camera>();
                        Ray ray = cam.ScreenPointToRay(Mouse.current.position.ReadValue());
                        Physics.Raycast(ray, out hitinfo, 100);
                    }

                    if (GunSphere == null)
                    {
                        GunSphere = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                        GunSphere.transform.localScale = isSphereEnabled ? new Vector3(0.1f, 0.1f, 0.1f) : new Vector3(0f, 0f, 0f);
                        GunSphere.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
                        GunSphere.GetComponent<Renderer>().material.color = currentGunColor.color;  // Set initial color
                        GameObject.Destroy(GunSphere.GetComponent<BoxCollider>());
                        GameObject.Destroy(GunSphere.GetComponent<Rigidbody>());
                        GameObject.Destroy(GunSphere.GetComponent<Collider>());

                        lineRenderer = GunSphere.AddComponent<LineRenderer>();
                        lineRenderer.material = new Material(Shader.Find("Sprites/Default"));
                        lineRenderer.widthCurve = AnimationCurve.Linear(0, 0.01f, 1, 0.01f);
                        lineRenderer.startColor = currentGunColor.color;  // Set initial color
                        lineRenderer.endColor = currentGunColor.color;

                        linePositions = new Vector3[50];
                        for (int i = 0; i < linePositions.Length; i++)
                        {
                            linePositions[i] = GorillaLocomotion.GTPlayer.Instance.rightControllerTransform.position;
                        }
                    }

                    GunSphere.transform.position = hitinfo.point;

                    timeCounter += Time.deltaTime;

                    Vector3 pos1 = GorillaLocomotion.GTPlayer.Instance.rightControllerTransform.position;
                    Vector3 direction = (hitinfo.point - pos1).normalized;
                    float distance = Vector3.Distance(pos1, hitinfo.point);

                    Vector3 controller = pos1 - previousControllerPosition;
                    previousControllerPosition = pos1;

                    if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f || Mouse.current.leftButton.isPressed)
                    {
                        act();
                    }

                    for (int i = 0; i < linePositions.Length; i++)
                    {
                        float t = i / (float)(linePositions.Length - 1);
                        Vector3 linePos = Vector3.Lerp(pos1, hitinfo.point, t);

                        linePositions[i] += controller * 0.5f;
                        linePositions[i] += UnityEngine.Random.insideUnitSphere * 0.01f;
                        linePositions[i] = Vector3.Lerp(linePositions[i], linePos, Time.deltaTime * num);
                    }

                    lineRenderer.positionCount = linePositions.Length;
                    lineRenderer.SetPositions(linePositions);

                    // Apply the current color to the gun and the line renderer
                    GunSphere.GetComponent<Renderer>().material.color = currentGunColor.color;
                    lineRenderer.startColor = currentGunColor.color;
                    lineRenderer.endColor = currentGunColor.color;
                }
            }

            if (GunSphere != null && (ControllerInputPoller.instance.rightControllerGripFloat <= 0.1f && !UnityInput.Current.GetMouseButton(1)))
            {
                GameObject.Destroy(GunSphere);
                GameObject.Destroy(lineRenderer);
                timeCounter = 0f;
                linePositions = null;
            }
        }


    }
}
