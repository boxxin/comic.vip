﻿using AetherTemp.Classes;
using BepInEx;
using GorillaNetworking;
using Photon.Pun;
using PlayFab.ClientModels;
using StupidTemplate;
using StupidTemplate.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using UnityEngine.InputSystem;

namespace AetherTemp.Menu
{
    [BepInPlugin("boii.ts.gui", "comic.gui", "1.0.0")]
    public class poopgui : BaseUnityPlugin
    {
        public static bool bazinga = false;
        public static bool bazinga2 = false;
        public static int r;
        public static int g;
        public static int b;
        public static string room = "Put Room Here";
        public static string[] buttons = new string[9999];
        public static string strang = "";

        public void OnGUI()
        {
            List<string> strings = new List<string>();
            foreach (ButtonInfo[] buttonInfos in Buttons.buttons)
            {
                foreach (ButtonInfo buttonInfo in buttonInfos)
                {
                    if (buttonInfo.enabled)
                    {
                        strings.Add(buttonInfo.buttonText);
                    }
                }
            }
            strings.Sort();
            int i = 0;
            for (int l = 0; l < buttons.Count(); l++)
            {
                buttons[i] = "";
                i++;
            }
            i = 0;
            foreach (string strig in strings)
            {
                buttons[i] += "|" + strig + "|\n";
                string duhh2 = buttons[i];
                string updated2 = "";
                float t2 = Mathf.PingPong(Time.time, 1f);
                int num2;
                for (int j = 0; j < duhh2.Length; j = num2 + 1)
                {
                    float letterPos = (float)j / (float)(duhh2.Length - 1);
                    float blend = Mathf.PingPong(Time.time + letterPos, 1f);
                    Color color = Color.Lerp(Color.white, Settings.buuu, blend);
                    updated2 += $"<color=#{ColorUtility.ToHtmlStringRGB(color)}>{duhh2[j]}</color>";
                    num2 = j;
                }
                buttons[i] = updated2;
                i++;
            }
            strang = string.Join("", buttons);
            GUI.skin.label.fontSize = 16;
            GUI.skin.label.font = Settings.currentFont;
            GUI.skin.label.alignment = TextAnchor.UpperRight;
            GUI.Label(new Rect(0, 0, Screen.width - 20f, Screen.height), strang);
            string stra = "comic";
            string duhh = stra;
            string updated = "";
            float t = Mathf.PingPong(Time.time, 1f);
            int num;
            for (int j = 0; j < duhh.Length; j = num + 1)
            {
                float letterPos = (float)j / (float)(duhh.Length - 1);
                float blend = Mathf.PingPong(Time.time + letterPos, 1f);
                Color color = Color.Lerp(Color.white, Settings.buuu, blend);
                updated += $"<color=#{ColorUtility.ToHtmlStringRGB(color)}>{duhh[j]}</color>";
                num = j;
            }
            stra = updated;
            GUI.skin.label.fontSize = 18;
            GUI.skin.label.font = Settings.currentFont;
            GUI.skin.label.alignment = TextAnchor.UpperLeft;
            //GUI.Label(new Rect(0, 0, Screen.width - 20f, Screen.height), stra);
            GUILayout.Label(stra);
            GUIStyle gUIStyle = new GUIStyle(GUI.skin.button);
            gUIStyle.normal.textColor = Color.white;
            gUIStyle.normal.background = MakeTex(2, 2, Color.black); 
            GUILayout.BeginVertical();
            GUILayout.Box("", GUILayout.Width(100), GUILayout.Height(175));
            GUI.backgroundColor = BetterColors.dark;

            GUILayout.BeginArea(new Rect(5, 5, 100, 180));
            GUILayout.Space(20);

            if (GUILayout.Button("Disconnect", GUILayout.Height(25), GUILayout.Width(90)))
            {
                PhotonNetwork.Disconnect();
            }
            if (GUILayout.Button("Join Rand", GUILayout.Height(25), GUILayout.Width(90)))
            {
                PhotonNetwork.JoinRandomRoom();
            }
            if (GUILayout.Button("Join Room", GUILayout.Height(25), GUILayout.Width(90)))
            {
                PhotonNetworkController.Instance.AttemptToJoinSpecificRoom(room, JoinType.Solo);
            }
            if (GUILayout.Button("Set Name", GUILayout.Height(25), GUILayout.Width(90)))
            {
                PhotonNetwork.NickName = room.ToUpper();
                NetworkSystem.Instance.name = room.ToUpper();
                GorillaComputer.instance.name = room.ToUpper();
                GorillaComputer.instance.savedName = room.ToUpper();
                PhotonNetwork.LocalPlayer.NickName = room.ToUpper();
                NetworkSystem.Instance.SetMyNickName(room.ToUpper());
                GorillaComputer.instance.currentName = room.ToUpper();
                PhotonNetwork.NetworkingClient.NickName = room.ToUpper();
                GorillaLocomotion.GTPlayer.Instance.name = room.ToUpper();
                PlayerPrefs.SetString("playerName", room.ToUpper());
                PlayerPrefs.Save();
            }
            if (GUILayout.Button("WASD", GUILayout.Height(25), GUILayout.Width(90)))
            {
                bazinga = true;
            }
            room = GUILayout.TextField(room, GUILayout.Height(45), GUILayout.Width(90));
            GUILayout.EndArea();
            GUILayout.EndVertical();
            if (bazinga)
            {
                toilet();
            }
        }
        private Texture2D MakeTex(int width, int height, Color color)
        {
            Texture2D tex = new Texture2D(width, height);
            Color[] pixels = new Color[width * height];

            for (int i = 0; i < pixels.Length; i++)
            {
                pixels[i] = color;
            }

            tex.SetPixels(pixels);
            tex.Apply();
            return tex;
        }
        public static void toilet()
        {
            float speed = 5f;
            if (Mouse.current.rightButton.isPressed)
            {
                Vector3 euler = GorillaLocomotion.GTPlayer.Instance.rightControllerTransform.parent.rotation.eulerAngles;
                euler.y += Mouse.current.delta.x.ReadValue() / Screen.width * 480f;
                euler.x -= Mouse.current.delta.y.ReadValue() / Screen.height * 480f;
                GorillaLocomotion.GTPlayer.Instance.rightControllerTransform.parent.rotation = Quaternion.Euler(euler);
            }
            if (UnityInput.Current.GetKey(KeyCode.LeftShift))
            {
                speed = 25f;
            }
            else
            {
                speed = 15f;
            }
            if (UnityInput.Current.GetKey(KeyCode.W))
            {
                GorillaLocomotion.GTPlayer.Instance.transform.position += GorillaLocomotion.GTPlayer.Instance.headCollider.transform.forward * Time.deltaTime * speed;
                GorillaLocomotion.GTPlayer.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
            }
            if (UnityInput.Current.GetKey(KeyCode.S))
            {
                GorillaLocomotion.GTPlayer.Instance.transform.position += GorillaLocomotion.GTPlayer.Instance.headCollider.transform.forward * Time.deltaTime * -speed;
                GorillaLocomotion.GTPlayer.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
            }
            if (UnityInput.Current.GetKey(KeyCode.A))
            {
                GorillaLocomotion.GTPlayer.Instance.transform.position += GorillaLocomotion.GTPlayer.Instance.headCollider.transform.right * Time.deltaTime * -speed;
                GorillaLocomotion.GTPlayer.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
            }
            if (UnityInput.Current.GetKey(KeyCode.D))
            {
                GorillaLocomotion.GTPlayer.Instance.transform.position += GorillaLocomotion.GTPlayer.Instance.headCollider.transform.right * Time.deltaTime * speed;
                GorillaLocomotion.GTPlayer.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
            }
            if (UnityInput.Current.GetKey(KeyCode.Space))
            {
                GorillaLocomotion.GTPlayer.Instance.transform.position += GorillaLocomotion.GTPlayer.Instance.headCollider.transform.up * Time.deltaTime * speed;
                GorillaLocomotion.GTPlayer.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
            }
            if (UnityInput.Current.GetKey(KeyCode.LeftControl))
            {
                GorillaLocomotion.GTPlayer.Instance.transform.position += GorillaLocomotion.GTPlayer.Instance.headCollider.transform.up * Time.deltaTime * -speed;
                GorillaLocomotion.GTPlayer.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
            }
        }
    }
}
