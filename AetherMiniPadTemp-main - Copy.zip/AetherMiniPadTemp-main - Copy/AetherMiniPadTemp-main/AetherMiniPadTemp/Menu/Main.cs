﻿using AetherTemp.Classes;
using AetherTemp.Menu;
using BepInEx;
using GorillaNetworking;
using HarmonyLib;
using Photon.Pun;
using StupidTemplate.Classes;
using StupidTemplate.Mods;
using StupidTemplate.Notifications;
using System;
using System.Collections;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using TMPro;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.Rendering;
using UnityEngine.UI;
using UnityEngine.XR;
using static AetherTemp.Menu.Buttons;
using static Fusion.Sockets.NetBitBuffer;
using static StupidTemplate.Settings;
using static System.Net.Mime.MediaTypeNames;
using Color = UnityEngine.Color;
using Text = UnityEngine.UI.Text;

namespace StupidTemplate.Menu
{
    [HarmonyPatch(typeof(GorillaLocomotion.GTPlayer))]
    [HarmonyPatch("LateUpdate", MethodType.Normal)]
    public class Main : MonoBehaviour
    {
        // Constant
        public static float num = 2f;
        public static int num2 = 144;

        public static void MenuDeleteTime()
        {
            if (num == 2f)
                num = 5f; // Long
            else if (num == 5f)
                num = 0.01f; // Fast
            else
                num = 2f; // Default
        }
        public static void NotifDeleteTime()
        {
            if (num2 == 144)
                num2 = 177; // Long
            else if (num2 == 177)
                num2 = 14; // Fast
            else
                num2 = 144; // Default
        }

        public static float rt;
        public static float lt;
        public static void Prefix()
        {
            try
            {
                if (!Directory.Exists("comic"))
                {
                    Directory.CreateDirectory("comic");
                }
                rt = ControllerInputPoller.TriggerFloat(XRNode.RightHand);
                lt = ControllerInputPoller.TriggerFloat(XRNode.LeftHand);
                bool toOpen = (!rightHanded && ControllerInputPoller.instance.leftControllerSecondaryButton) || (rightHanded && ControllerInputPoller.instance.rightControllerSecondaryButton);
                bool keyboardOpen = UnityInput.Current.GetKey(keyboardButton);
                if (menu == null)
                {
                    if (toOpen || keyboardOpen)
                    {
                        CreateMenu();
                        RecenterMenu(rightHanded, keyboardOpen);
                        if (reference == null)
                        {
                            CreateReference(rightHanded);
                        }
                    }
                }
                else
                {
                    if (toOpen || keyboardOpen)
                    {
                        RecenterMenu(rightHanded, keyboardOpen);
                    }
                    else
                    {
                        GameObject.Find("Shoulder Camera").transform.Find("CM vcam1").gameObject.SetActive(true);

                        Rigidbody comp = menu.AddComponent(typeof(Rigidbody)) as Rigidbody;
                        if (rightHanded)
                        {
                            comp.velocity = new Vector3(UnityEngine.Random.Range(-5, 5), UnityEngine.Random.Range(-5, 5), UnityEngine.Random.Range(-5, 5));
                        }
                        else
                        {
                            comp.velocity = new Vector3(UnityEngine.Random.Range(-5, 5), UnityEngine.Random.Range(-5, 5), UnityEngine.Random.Range(-5, 5));
                        }

                        UnityEngine.Object.Destroy(menu, num);
                        menu = null;

                        UnityEngine.Object.Destroy(reference);
                        reference = null;
                    }
                }
            }
            catch (Exception exc)
            {
                UnityEngine.Debug.LogError(string.Format("{0} // Error initializing at {1}: {2}", PluginInfo.Name, exc.StackTrace, exc.Message));
            }
            try
            {
                bool toOpen = (!rightHanded && ControllerInputPoller.instance.leftControllerSecondaryButton) || (rightHanded && ControllerInputPoller.instance.rightControllerSecondaryButton);
                bool keyboardOpen = UnityInput.Current.GetKey(keyboardButton);
                bored();
                if (toOpen || keyboardOpen)
                {
                    NextPage();
                    PreviousPage();
                }
                if (fpsObject != null)
                {
                    fpsObject.text = "FPS: " + Mathf.Ceil(1f / Time.unscaledDeltaTime).ToString();
                    string duhh = "FPS: " + Mathf.Ceil(1f / Time.unscaledDeltaTime).ToString();
                    string updated = "";
                    float t = Mathf.PingPong(Time.time, 1f);
                    int num;
                    for (int j = 0; j < duhh.Length; j = num + 1)
                    {
                        float letterPos = (float)j / (float)(duhh.Length - 1);
                        float blend = Mathf.PingPong(Time.time + letterPos, 1f);
                        Color color = Color.Lerp(Color.white, buuu, blend);
                        updated += $"<color=#{ColorUtility.ToHtmlStringRGB(color)}>{duhh[j]}</color>";
                        num = j;
                    }
                    fpsObject.text = updated;
                }
                if (returnText != null)
                {
                    string duhh = "Return";
                    string updated = "";
                    float t = Mathf.PingPong(Time.time, 1f);
                    int num;
                    for (int j = 0; j < duhh.Length; j = num + 1)
                    {
                        float letterPos = (float)j / (float)(duhh.Length - 1);
                        float blend = Mathf.PingPong(Time.time + letterPos, 1f);
                        Color color = Color.Lerp(Color.white, buuu, blend);
                        updated += $"<color=#{ColorUtility.ToHtmlStringRGB(color)}>{duhh[j]}</color>";
                        num = j;
                    }
                    returnText.text = updated;
                }
                if (menuText != null)
                {
                    string duhh = PluginInfo.Name.ToString();
                    string updated = "";
                    float t = Mathf.PingPong(Time.time, 1f);
                    int num;
                    for (int j = 0; j < duhh.Length; j = num + 1)
                    {
                        float letterPos = (float)j / (float)(duhh.Length - 1);
                        float blend = Mathf.PingPong(Time.time + letterPos, 1f);
                        Color color = Color.Lerp(Color.white, buuu, blend);
                        updated += $"<color=#{ColorUtility.ToHtmlStringRGB(color)}>{duhh[j]}</color>";
                        num = j;
                    }
                    menuText.text = updated;
                }
                foreach (ButtonInfo[] buttonlist in buttons)
                {
                    foreach (ButtonInfo v in buttonlist)
                    {
                        if (v.enabled)
                        {
                            if (v.method != null)
                            {
                                try
                                {
                                    v.method.Invoke();
                                }
                                catch (Exception exc)
                                {
                                    UnityEngine.Debug.LogError(string.Format("{0} // Error with mod {1} at {2}: {3}", PluginInfo.Name, v.buttonText, exc.StackTrace, exc.Message));
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception exc)
            {
                UnityEngine.Debug.LogError(string.Format("{0} // Error with executing mods at {1}: {2}", PluginInfo.Name, exc.StackTrace, exc.Message));
            }

        }
        public class CoroutineHandler : MonoBehaviour
        {
            public static CoroutineHandler instance;
            public static CoroutineHandler Instance
            {
                get
                {
                    if (instance == null)
                    {
                        GameObject obj = new GameObject("CoroutineHandler");
                        obj.hideFlags = HideFlags.HideAndDontSave;
                        instance = obj.AddComponent<CoroutineHandler>();
                        GameObject.DontDestroyOnLoad(obj);
                    }
                    return instance;
                }
            }
        }
        Color peach = new Color(255f / 255f, 229f / 255f, 180f / 255f);
        Color mainc = new Color(176f / 255f, 153f / 255f, 128f / 255f);
        public static void CreateMenu()
        {
            menu = GameObject.CreatePrimitive(PrimitiveType.Cube);
            UnityEngine.Object.Destroy(menu.GetComponent<Rigidbody>());
            UnityEngine.Object.Destroy(menu.GetComponent<BoxCollider>());
            UnityEngine.Object.Destroy(menu.GetComponent<Renderer>());
            menu.transform.localScale = new Vector3(0.1f, 0.3f, 0.3825f);

            GameObject menuBackground = GameObject.CreatePrimitive(PrimitiveType.Cube);
            UnityEngine.Object.Destroy(menuBackground.GetComponent<Rigidbody>());
            UnityEngine.Object.Destroy(menuBackground.GetComponent<BoxCollider>());
            menuBackground.transform.parent = menu.transform;
            menuBackground.transform.rotation = Quaternion.identity;
            menuBackground.transform.localScale = menuSize;
            menuBackground.transform.position = new Vector3(0.05f, 0f, -0.02f);

            menuBackground.GetComponent<Renderer>().material.color = new Color32(10, 10, 10, 255);

            menuBackground.GetComponent<Renderer>().enabled = false;
            float bevel = 0.02f;


            GameObject BaseA = GameObject.CreatePrimitive(PrimitiveType.Cube);
            BaseA.GetComponent<Renderer>().enabled = true;
            UnityEngine.Object.Destroy(BaseA.GetComponent<Collider>());
            BaseA.transform.parent = menu.transform;
            BaseA.transform.rotation = Quaternion.identity;
            BaseA.transform.localPosition = menuBackground.transform.localPosition;
            BaseA.transform.localScale = menuBackground.transform.localScale + new Vector3(0f, bevel * -2.55f, 0f);

            GameObject BaseB = GameObject.CreatePrimitive(PrimitiveType.Cube);
            BaseB.GetComponent<Renderer>().enabled = true;
            UnityEngine.Object.Destroy(BaseB.GetComponent<Collider>());
            BaseB.transform.parent = menu.transform;
            BaseB.transform.rotation = Quaternion.identity;
            BaseB.transform.localPosition = menuBackground.transform.localPosition;
            BaseB.transform.localScale = menuBackground.transform.localScale + new Vector3(0f, 0f, -bevel * 2f);

            GameObject RoundCornerA = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            RoundCornerA.GetComponent<Renderer>().enabled = true;
            UnityEngine.Object.Destroy(RoundCornerA.GetComponent<Collider>());
            RoundCornerA.transform.parent = menu.transform;
            RoundCornerA.transform.rotation = Quaternion.Euler(0f, 0f, 90f);
            RoundCornerA.transform.localPosition = menuBackground.transform.localPosition + new Vector3(0f, (menuBackground.transform.localScale.y / 2f) - (bevel * 1.275f), (menuBackground.transform.localScale.z / 2f) - bevel);
            RoundCornerA.transform.localScale = new Vector3(bevel * 2.55f, menuBackground.transform.localScale.x / 2f, bevel * 2f);

            GameObject RoundCornerB = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            RoundCornerB.GetComponent<Renderer>().enabled = true;
            UnityEngine.Object.Destroy(RoundCornerB.GetComponent<Collider>());
            RoundCornerB.transform.parent = menu.transform;
            RoundCornerB.transform.rotation = Quaternion.Euler(0f, 0f, 90f);
            RoundCornerB.transform.localPosition = menuBackground.transform.localPosition + new Vector3(0f, -(menuBackground.transform.localScale.y / 2f) + (bevel * 1.275f), (menuBackground.transform.localScale.z / 2f) - bevel);
            RoundCornerB.transform.localScale = new Vector3(bevel * 2.55f, menuBackground.transform.localScale.x / 2f, bevel * 2f);

            GameObject RoundCornerC = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            RoundCornerC.GetComponent<Renderer>().enabled = true;
            UnityEngine.Object.Destroy(RoundCornerC.GetComponent<Collider>());
            RoundCornerC.transform.parent = menu.transform;
            RoundCornerC.transform.rotation = Quaternion.Euler(0f, 0f, 90f);
            RoundCornerC.transform.localPosition = menuBackground.transform.localPosition + new Vector3(0f, (menuBackground.transform.localScale.y / 2f) - (bevel * 1.275f), -(menuBackground.transform.localScale.z / 2f) + bevel);
            RoundCornerC.transform.localScale = new Vector3(bevel * 2.55f, menuBackground.transform.localScale.x / 2f, bevel * 2f);

            GameObject RoundCornerD = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            RoundCornerD.GetComponent<Renderer>().enabled = true;
            UnityEngine.Object.Destroy(RoundCornerD.GetComponent<Collider>());
            RoundCornerD.transform.parent = menu.transform;
            RoundCornerD.transform.rotation = Quaternion.Euler(0f, 0f, 90f);
            RoundCornerD.transform.localPosition = menuBackground.transform.localPosition + new Vector3(0f, -(menuBackground.transform.localScale.y / 2f) + (bevel * 1.275f), -(menuBackground.transform.localScale.z / 2f) + bevel);
            RoundCornerD.transform.localScale = new Vector3(bevel * 2.55f, menuBackground.transform.localScale.x / 2f, bevel * 2f);

            GameObject[] ToChange = new GameObject[]
            {
    BaseA,
    BaseB,
    RoundCornerA,
    RoundCornerB,
    RoundCornerC,
    RoundCornerD
            };

            foreach (GameObject obj in ToChange)
            {
                obj.GetComponent<Renderer>().material.color = new Color32(10, 10, 10, 255);
            }




            canvasObject = new GameObject();
            canvasObject.transform.parent = menu.transform;
            Canvas canvas = canvasObject.AddComponent<Canvas>();
            CanvasScaler canvasScaler = canvasObject.AddComponent<CanvasScaler>();
            canvasObject.AddComponent<GraphicRaycaster>();
            canvas.renderMode = RenderMode.WorldSpace;
            canvasScaler.dynamicPixelsPerUnit = 2000f;

            if (fpsCounter)
            {
                GameObject faffot = new GameObject("fpstxt");
                faffot.transform.parent = canvasObject.transform;
                faffot.transform.localScale = new Vector3(1.1f, 1.1f, 1.1f);
                fpsObject = faffot.AddComponent<Text>();
                fpsObject.font = currentFont;
                fpsObject.text = "FPS: " + Mathf.Ceil(1f / Time.unscaledDeltaTime).ToString();
                fpsObject.fontSize = 1;
                fpsObject.supportRichText = true;
                fpsObject.fontStyle = FontStyle.Italic;
                fpsObject.alignment = TextAnchor.MiddleCenter;
                fpsObject.horizontalOverflow = HorizontalWrapMode.Overflow;
                fpsObject.resizeTextForBestFit = true;
                fpsObject.resizeTextMinSize = 0;
                RectTransform component2 = fpsObject.GetComponent<RectTransform>();
                component2.localPosition = Vector3.zero;
                component2.sizeDelta = new Vector2(0.08f, 0.02f);
                component2.position = new Vector3(0.06f, 0.05f, -0.185f);
                component2.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
            }
            ColorChanger colorChanger;
            GameObject homebut = GameObject.CreatePrimitive(PrimitiveType.Cube);
            UnityEngine.Object.Destroy(homebut.GetComponent<Rigidbody>());
            homebut.GetComponent<BoxCollider>().isTrigger = true;
            homebut.transform.parent = menu.transform;
            homebut.transform.rotation = Quaternion.identity;
            homebut.transform.localScale = new Vector3(0.04f, 0.58f, 0.095f);
            homebut.transform.localPosition = new Vector3(0.56f, 0f, -0.34f);
            homebut.GetComponent<Renderer>().material.color = new Color32(30, 30, 30, 255);
            homebut.AddComponent<Classes.Button>().relatedText = "home";
            homebut.GetComponent<Renderer>().enabled = false;
            makeonjround(homebut, new Color32(30, 30, 30, 255));
            colorChanger = homebut.AddComponent<ColorChanger>();
            colorChanger.colorInfo = buttonColors[0];
            colorChanger.Start();
            GameObject faffot2 = new GameObject("hometxt");
            faffot2.transform.parent = canvasObject.transform;
            faffot2.transform.localScale = new Vector3(1.1f, 1.1f, 1.1f);
            returnText = faffot2.AddComponent<Text>();
            returnText.font = currentFont;
            returnText.text = "Return";
            returnText.fontSize = 1;
            returnText.supportRichText = true;
            returnText.alignment = TextAnchor.MiddleCenter;
            returnText.resizeTextForBestFit = true;
            returnText.resizeTextMinSize = 0;
            RectTransform component = returnText.GetComponent<RectTransform>();
            component.localPosition = Vector3.zero;
            component.sizeDelta = new Vector2(.05f, .02f);
            component.localPosition = new Vector3(0.064f, 0f, -0.12f);
            component.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));

            if (!disableMenuText)
            {
                GameObject faffot22 = new GameObject("menutxt");
                faffot22.transform.parent = canvasObject.transform;
                faffot22.transform.localScale = new Vector3(1.1f, 1.1f, 1.1f);
                menuText = faffot22.AddComponent<Text>();
                menuText.font = currentFont;
                menuText.text = PluginInfo.Name.ToString();
                menuText.fontSize = 1;
                menuText.supportRichText = true;
                menuText.fontStyle = FontStyle.Italic;
                menuText.alignment = TextAnchor.MiddleCenter;
                menuText.resizeTextForBestFit = true;
                menuText.resizeTextMinSize = 0;
                RectTransform component2 = menuText.GetComponent<RectTransform>();
                component2.localPosition = Vector3.zero;
                component2.sizeDelta = new Vector2(0.08f, 0.05f);
                component2.localPosition = new Vector3(0.064f, 0f, 0.118f);
                component2.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
            }
            MakeOutlines();
            ButtonInfo[] activeButtons = buttons[buttonsType].Skip(pageNumber * buttonsPerPage).Take(buttonsPerPage).ToArray();
                for (int i = 0; i < activeButtons.Length; i++)
                {
                    CreateButton(i * 0.095f, activeButtons[i]);
                }
            }
        public static void MakeOutlines()
        {
            GameObject menuBackground = GameObject.CreatePrimitive(PrimitiveType.Cube);
            UnityEngine.Object.Destroy(menuBackground.GetComponent<Rigidbody>());
            UnityEngine.Object.Destroy(menuBackground.GetComponent<BoxCollider>());
            menuBackground.transform.parent = menu.transform;
            menuBackground.transform.rotation = Quaternion.identity;
            menuBackground.transform.localScale = new Vector3(0.08f, 0.607f, 0.757f);
            menuBackground.transform.position = new Vector3(0.05f, 0f, -0.02f);

            menuBackground.GetComponent<Renderer>().material.color = BetterColors.darkGrey;

            menuBackground.GetComponent<Renderer>().enabled = false;
            float bevel = 0.02f;


            GameObject BaseA = GameObject.CreatePrimitive(PrimitiveType.Cube);
            BaseA.GetComponent<Renderer>().enabled = true;
            UnityEngine.Object.Destroy(BaseA.GetComponent<Collider>());
            BaseA.transform.parent = menu.transform;
            BaseA.transform.rotation = Quaternion.identity;
            BaseA.transform.localPosition = menuBackground.transform.localPosition;
            BaseA.transform.localScale = menuBackground.transform.localScale + new Vector3(0f, bevel * -2.55f, 0f);

            GameObject BaseB = GameObject.CreatePrimitive(PrimitiveType.Cube);
            BaseB.GetComponent<Renderer>().enabled = true;
            UnityEngine.Object.Destroy(BaseB.GetComponent<Collider>());
            BaseB.transform.parent = menu.transform;
            BaseB.transform.rotation = Quaternion.identity;
            BaseB.transform.localPosition = menuBackground.transform.localPosition;
            BaseB.transform.localScale = menuBackground.transform.localScale + new Vector3(0f, 0f, -bevel * 2f);

            GameObject RoundCornerA = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            RoundCornerA.GetComponent<Renderer>().enabled = true;
            UnityEngine.Object.Destroy(RoundCornerA.GetComponent<Collider>());
            RoundCornerA.transform.parent = menu.transform;
            RoundCornerA.transform.rotation = Quaternion.Euler(0f, 0f, 90f);
            RoundCornerA.transform.localPosition = menuBackground.transform.localPosition + new Vector3(0f, (menuBackground.transform.localScale.y / 2f) - (bevel * 1.275f), (menuBackground.transform.localScale.z / 2f) - bevel);
            RoundCornerA.transform.localScale = new Vector3(bevel * 2.55f, menuBackground.transform.localScale.x / 2f, bevel * 2f);

            GameObject RoundCornerB = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            RoundCornerB.GetComponent<Renderer>().enabled = true;
            UnityEngine.Object.Destroy(RoundCornerB.GetComponent<Collider>());
            RoundCornerB.transform.parent = menu.transform;
            RoundCornerB.transform.rotation = Quaternion.Euler(0f, 0f, 90f);
            RoundCornerB.transform.localPosition = menuBackground.transform.localPosition + new Vector3(0f, -(menuBackground.transform.localScale.y / 2f) + (bevel * 1.275f), (menuBackground.transform.localScale.z / 2f) - bevel);
            RoundCornerB.transform.localScale = new Vector3(bevel * 2.55f, menuBackground.transform.localScale.x / 2f, bevel * 2f);

            GameObject RoundCornerC = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            RoundCornerC.GetComponent<Renderer>().enabled = true;
            UnityEngine.Object.Destroy(RoundCornerC.GetComponent<Collider>());
            RoundCornerC.transform.parent = menu.transform;
            RoundCornerC.transform.rotation = Quaternion.Euler(0f, 0f, 90f);
            RoundCornerC.transform.localPosition = menuBackground.transform.localPosition + new Vector3(0f, (menuBackground.transform.localScale.y / 2f) - (bevel * 1.275f), -(menuBackground.transform.localScale.z / 2f) + bevel);
            RoundCornerC.transform.localScale = new Vector3(bevel * 2.55f, menuBackground.transform.localScale.x / 2f, bevel * 2f);

            GameObject RoundCornerD = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            RoundCornerD.GetComponent<Renderer>().enabled = true;
            UnityEngine.Object.Destroy(RoundCornerD.GetComponent<Collider>());
            RoundCornerD.transform.parent = menu.transform;
            RoundCornerD.transform.rotation = Quaternion.Euler(0f, 0f, 90f);
            RoundCornerD.transform.localPosition = menuBackground.transform.localPosition + new Vector3(0f, -(menuBackground.transform.localScale.y / 2f) + (bevel * 1.275f), -(menuBackground.transform.localScale.z / 2f) + bevel);
            RoundCornerD.transform.localScale = new Vector3(bevel * 2.55f, menuBackground.transform.localScale.x / 2f, bevel * 2f);

            GameObject[] ToChange = new GameObject[]
            {
    BaseA,
    BaseB,
    RoundCornerA,
    RoundCornerB,
    RoundCornerC,
    RoundCornerD
            };

            foreach (GameObject obj in ToChange)
            {
                obj.GetComponent<Renderer>().material.color = BetterColors.darkGrey;
            }
        }
        public static Text returnText;
        public static Text menuText;
        public static Text buttText;

        public static void makeonjround(GameObject menuBackground, Color color)
        {
            float bevel = 0.02f;


            GameObject BaseA = GameObject.CreatePrimitive(PrimitiveType.Cube);
            BaseA.GetComponent<Renderer>().enabled = true;
            UnityEngine.Object.Destroy(BaseA.GetComponent<Collider>());
            BaseA.transform.parent = menu.transform;
            BaseA.transform.rotation = Quaternion.identity;
            BaseA.transform.localPosition = menuBackground.transform.localPosition;
            BaseA.transform.localScale = menuBackground.transform.localScale + new Vector3(0f, bevel * -2.55f, 0f);

            GameObject BaseB = GameObject.CreatePrimitive(PrimitiveType.Cube);
            BaseB.GetComponent<Renderer>().enabled = true;
            UnityEngine.Object.Destroy(BaseB.GetComponent<Collider>());
            BaseB.transform.parent = menu.transform;
            BaseB.transform.rotation = Quaternion.identity;
            BaseB.transform.localPosition = menuBackground.transform.localPosition;
            BaseB.transform.localScale = menuBackground.transform.localScale + new Vector3(0f, 0f, -bevel * 2f);

            GameObject RoundCornerA = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            RoundCornerA.GetComponent<Renderer>().enabled = true;
            UnityEngine.Object.Destroy(RoundCornerA.GetComponent<Collider>());
            RoundCornerA.transform.parent = menu.transform;
            RoundCornerA.transform.rotation = Quaternion.Euler(0f, 0f, 90f);
            RoundCornerA.transform.localPosition = menuBackground.transform.localPosition + new Vector3(0f, (menuBackground.transform.localScale.y / 2f) - (bevel * 1.275f), (menuBackground.transform.localScale.z / 2f) - bevel);
            RoundCornerA.transform.localScale = new Vector3(bevel * 2.55f, menuBackground.transform.localScale.x / 2f, bevel * 2f);

            GameObject RoundCornerB = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            RoundCornerB.GetComponent<Renderer>().enabled = true;
            UnityEngine.Object.Destroy(RoundCornerB.GetComponent<Collider>());
            RoundCornerB.transform.parent = menu.transform;
            RoundCornerB.transform.rotation = Quaternion.Euler(0f, 0f, 90f);
            RoundCornerB.transform.localPosition = menuBackground.transform.localPosition + new Vector3(0f, -(menuBackground.transform.localScale.y / 2f) + (bevel * 1.275f), (menuBackground.transform.localScale.z / 2f) - bevel);
            RoundCornerB.transform.localScale = new Vector3(bevel * 2.55f, menuBackground.transform.localScale.x / 2f, bevel * 2f);

            GameObject RoundCornerC = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            RoundCornerC.GetComponent<Renderer>().enabled = true;
            UnityEngine.Object.Destroy(RoundCornerC.GetComponent<Collider>());
            RoundCornerC.transform.parent = menu.transform;
            RoundCornerC.transform.rotation = Quaternion.Euler(0f, 0f, 90f);
            RoundCornerC.transform.localPosition = menuBackground.transform.localPosition + new Vector3(0f, (menuBackground.transform.localScale.y / 2f) - (bevel * 1.275f), -(menuBackground.transform.localScale.z / 2f) + bevel);
            RoundCornerC.transform.localScale = new Vector3(bevel * 2.55f, menuBackground.transform.localScale.x / 2f, bevel * 2f);

            GameObject RoundCornerD = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            RoundCornerD.GetComponent<Renderer>().enabled = true;
            UnityEngine.Object.Destroy(RoundCornerD.GetComponent<Collider>());
            RoundCornerD.transform.parent = menu.transform;
            RoundCornerD.transform.rotation = Quaternion.Euler(0f, 0f, 90f);
            RoundCornerD.transform.localPosition = menuBackground.transform.localPosition + new Vector3(0f, -(menuBackground.transform.localScale.y / 2f) + (bevel * 1.275f), -(menuBackground.transform.localScale.z / 2f) + bevel);
            RoundCornerD.transform.localScale = new Vector3(bevel * 2.55f, menuBackground.transform.localScale.x / 2f, bevel * 2f);

            GameObject[] ToChange = new GameObject[]
            {
    BaseA,
    BaseB,
    RoundCornerA,
    RoundCornerB,
    RoundCornerC,
    RoundCornerD
            };

            foreach (GameObject obj in ToChange)
            {
                obj.GetComponent<Renderer>().material.color = color;
            }
        }

        public static GameObject trailObject;

        public static Vector3 buttonSize = new Vector3(0.04f, 0.58f, 0.095f);
        public static void CreateButton(float offset, ButtonInfo method)
        {

            GameObject gameObject = GameObject.CreatePrimitive(PrimitiveType.Cube);
            if (!UnityInput.Current.GetKey(KeyCode.Q))
            {
                gameObject.layer = 2;
            }
            UnityEngine.Object.Destroy(gameObject.GetComponent<Rigidbody>());
            gameObject.GetComponent<BoxCollider>().isTrigger = true;
            gameObject.transform.parent = menu.transform;
            gameObject.transform.rotation = Quaternion.identity;

            gameObject.transform.localScale = buttonSize;
            gameObject.transform.localPosition = new Vector3(0.56f, 0f, 0.23f - offset);

            gameObject.GetComponent<Renderer>().enabled = false;
            Color color = new Color32(15, 15, 15, 255);
            Color color2 = new Color32(30, 30, 30, 255);
            float Bevel = 0.02f;
            GameObject BaseA = GameObject.CreatePrimitive(PrimitiveType.Cube);
            BaseA.GetComponent<Renderer>().enabled = true;  
            UnityEngine.Object.Destroy(BaseA.GetComponent<Collider>());
            BaseA.transform.parent = menu.transform;
            BaseA.transform.rotation = Quaternion.identity;
            BaseA.transform.localPosition = gameObject.transform.localPosition;
            BaseA.transform.localScale = gameObject.transform.localScale + new Vector3(0f, Bevel * -2.55f, 0f);
            BaseA.GetComponent<Renderer>().material.color = new Color32(30, 30, 30, 255);
            if (method.enabled)
            {
                BaseA.GetComponent<Renderer>().material.color = color;
            }
            else
            {
                BaseA.GetComponent<Renderer>().material.color = color2;
            }

            GameObject BaseB = GameObject.CreatePrimitive(PrimitiveType.Cube);
            BaseB.GetComponent<Renderer>().enabled = true;  
            UnityEngine.Object.Destroy(BaseB.GetComponent<Collider>());
            BaseB.transform.parent = menu.transform;
            BaseB.transform.rotation = Quaternion.identity;
            BaseB.transform.localPosition = gameObject.transform.localPosition;
            BaseB.transform.localScale = gameObject.transform.localScale + new Vector3(0f, 0f, -Bevel * 2f);
            BaseB.GetComponent<Renderer>().material.color = new Color32(30, 30, 30, 255);
            if (method.enabled)
            {
                BaseB.GetComponent<Renderer>().material.color = color;
            }
            else
            {
                BaseB.GetComponent<Renderer>().material.color = color2;
            }

            GameObject RoundCornerA = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            RoundCornerA.GetComponent<Renderer>().enabled = true;
            UnityEngine.Object.Destroy(RoundCornerA.GetComponent<Collider>());
            RoundCornerA.transform.parent = menu.transform;
            RoundCornerA.transform.rotation = Quaternion.identity * Quaternion.Euler(0f, 0f, 90f);
            RoundCornerA.transform.localPosition = gameObject.transform.localPosition + new Vector3(0f, (gameObject.transform.localScale.y / 2f) - (Bevel * 1.275f), (gameObject.transform.localScale.z / 2f) - Bevel);
            RoundCornerA.transform.localScale = new Vector3(Bevel * 2.55f, gameObject.transform.localScale.x / 2f, Bevel * 2f);
            RoundCornerA.GetComponent<Renderer>().material.color = new Color32(30, 30, 30, 255);
            if (method.enabled)
            {
                RoundCornerA.GetComponent<Renderer>().material.color = color;
            }
            else
            {
                RoundCornerA.GetComponent<Renderer>().material.color = color2;
            }

            GameObject RoundCornerB = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            RoundCornerB.GetComponent<Renderer>().enabled = true; 
            UnityEngine.Object.Destroy(RoundCornerB.GetComponent<Collider>());
            RoundCornerB.transform.parent = menu.transform;
            RoundCornerB.transform.rotation = Quaternion.identity * Quaternion.Euler(0f, 0f, 90f);
            RoundCornerB.transform.localPosition = gameObject.transform.localPosition + new Vector3(0f, -(gameObject.transform.localScale.y / 2f) + (Bevel * 1.275f), (gameObject.transform.localScale.z / 2f) - Bevel);
            RoundCornerB.transform.localScale = new Vector3(Bevel * 2.55f, gameObject.transform.localScale.x / 2f, Bevel * 2f);
            RoundCornerB.GetComponent<Renderer>().material.color = new Color32(30, 30, 30, 255);
            if (method.enabled)
            {
                RoundCornerB.GetComponent<Renderer>().material.color = color;
            }
            else
            {
                RoundCornerB.GetComponent<Renderer>().material.color = color2;
            }

            GameObject RoundCornerC = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            RoundCornerC.GetComponent<Renderer>().enabled = true;  
            UnityEngine.Object.Destroy(RoundCornerC.GetComponent<Collider>());
            RoundCornerC.transform.parent = menu.transform;
            RoundCornerC.transform.rotation = Quaternion.identity * Quaternion.Euler(0f, 0f, 90f);
            RoundCornerC.transform.localPosition = gameObject.transform.localPosition + new Vector3(0f, (gameObject.transform.localScale.y / 2f) - (Bevel * 1.275f), -(gameObject.transform.localScale.z / 2f) + Bevel);
            RoundCornerC.transform.localScale = new Vector3(Bevel * 2.55f, gameObject.transform.localScale.x / 2f, Bevel * 2f);
            RoundCornerC.GetComponent<Renderer>().material.color = new Color32(30, 30, 30, 255);
            if (method.enabled)
            {
                RoundCornerC.GetComponent<Renderer>().material.color = color;
            }
            else
            {
                RoundCornerC.GetComponent<Renderer>().material.color = color2;
            }

            GameObject RoundCornerD = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            RoundCornerD.GetComponent<Renderer>().enabled = true; 
            UnityEngine.Object.Destroy(RoundCornerD.GetComponent<Collider>());
            RoundCornerD.transform.parent = menu.transform;
            RoundCornerD.transform.rotation = Quaternion.identity * Quaternion.Euler(0f, 0f, 90f);
            RoundCornerD.transform.localPosition = gameObject.transform.localPosition + new Vector3(0f, -(gameObject.transform.localScale.y / 2f) + (Bevel * 1.275f), -(gameObject.transform.localScale.z / 2f) + Bevel);
            RoundCornerD.transform.localScale = new Vector3(Bevel * 2.55f, gameObject.transform.localScale.x / 2f, Bevel * 2f);
            RoundCornerD.GetComponent<Renderer>().material.color = new Color32(30, 30, 30, 255);
            if (method.enabled)
            {
                RoundCornerD.GetComponent<Renderer>().material.color = color;
            }
            else
            {
                RoundCornerD.GetComponent<Renderer>().material.color = color2;
            }

            gameObject.AddComponent<Classes.Button>().relatedText = method.buttonText;

            //gameObject.GetComponent<Renderer>().material.color = new Color32(30, 30, 30, 255);
            if (method.enabled)
            {
                gameObject.GetComponent<Renderer>().material.color = color;
            }
            else
            {
                gameObject.GetComponent<Renderer>().material.color = color2;
            }


            ColorChanger colorChanger = gameObject.AddComponent<ColorChanger>();
            if (method.enabled)
            {
                colorChanger.colorInfo = buttonColors[1];
            }
            else
            {
                colorChanger.colorInfo = buttonColors[0];
            }
            colorChanger.Start();

            buttText = new GameObject
            {
                transform =
                {
                    parent = canvasObject.transform
                }
            }.AddComponent<Text>();
            buttText.font = currentFont;
            buttText.text = method.buttonText;
            if (method.overlapText != null)
            {
                buttText.text = method.overlapText;
            }
            string duhh = buttText.text;
            string updated = "";
            float t = Mathf.PingPong(Time.time, 1f);
            int num;
            for (int j = 0; j < duhh.Length; j = num + 1)
            {
                float letterPos = (float)j / (float)(duhh.Length - 1);
                float blend = Mathf.PingPong(Time.time + letterPos, 1f);
                Color color22 = Color.Lerp(Color.white, buuu, blend);
                updated += $"<color=#{ColorUtility.ToHtmlStringRGB(color22)}>{duhh[j]}</color>";
                num = j;
            }
            buttText.text = updated;
            buttText.supportRichText = true;
            buttText.fontSize = 1;
            buttText.alignment = TextAnchor.MiddleCenter;
            buttText.fontStyle = FontStyle.Italic;
            buttText.resizeTextForBestFit = true;
            buttText.resizeTextMinSize = 0;
            RectTransform component = buttText.GetComponent<RectTransform>();
            component.localPosition = Vector3.zero;
            component.sizeDelta = new Vector2(.05f, .02f);
            component.localPosition = new Vector3(0.061f, 0, 0.09f - offset / 2.6f);
            component.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));

        }
        public static GameObject coc1;
        public static void bored()
        {
            coc1 = GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/CodeOfConduct");
            coc1.GetComponent<TextMeshPro>().text = "comic.vip";
            string duhh = coc1.GetComponent<TextMeshPro>().text;
            string updated = "";
            float speed = 2f;
            int num;
            for (int j = 0; j < duhh.Length; j = num + 1)
            {
                float letterOffset = (float)j / duhh.Length;
                float wave = Mathf.Sin((Time.time * speed + letterOffset * Mathf.PI * 2f));
                float t = (wave + 1f) / 2f;
                fucktuah = Color.Lerp(Color.white, buuu, t);
                updated += $"<color=#{ColorUtility.ToHtmlStringRGB(fucktuah)}>{duhh[j]}</color>";
                num = j;
            }
            coc1.GetComponent<TextMeshPro>().text = updated;
            GameObject coc2 = GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/COC Text");
            coc2.GetComponent<TextMeshPro>().text = "Welcome To Comic.VIP\nYour version is: "+ PluginInfo.Version + "\nYour FPS is: " + Mathf.Ceil(1f / Time.unscaledDeltaTime).ToString() + "\nIs master " + PhotonNetwork.IsMasterClient +"\nPing: " + PhotonNetwork.GetPing() +"";
            GameObject motdtext = GameObject.Find("motdtext");
            motdtext.GetComponent<TextMeshPro>().text = "Welcome to comic.vip.\nAdded: Released!!\nRemoved: Nothing\nStatus: UND";
            string duhh22 = motdtext.GetComponent<TextMeshPro>().text;
            string updated22 = "";
            float speed22 = 2f;
            int num22;
            for (int j2 = 0; j2 < duhh22.Length; j2 = num22 + 1)
            {
                float letterOffset2 = (float)j2 / duhh22.Length;
                float wave2 = Mathf.Sin((Time.time * speed22 + letterOffset2 * Mathf.PI * 2f));
                float t2 = (wave2 + 1f) / 2f;
                fucktuah = Color.Lerp(Color.white, buuu, t2);
                updated22 += $"<color=#{ColorUtility.ToHtmlStringRGB(fucktuah)}>{duhh22[j2]}</color>";
                num22 = j2;
            }
            motdtext.GetComponent<TextMeshPro>().text = updated22;
            GameObject motd = GameObject.Find("motd (1)");
            motd.GetComponent<TextMeshPro>().text = "comic.vip";
            string duhh222 = motd.GetComponent<TextMeshPro>().text;
            string updated222 = "";
            float speed222 = 2f;
            int num222;
            for (int j2 = 0; j2 < duhh222.Length; j2 = num222 + 1)
            {
                float letterOffset2 = (float)j2 / duhh222.Length;
                float wave2 = Mathf.Sin((Time.time * speed222 + letterOffset2 * Mathf.PI * 2f));
                float t2 = (wave2 + 1f) / 2f;
                fucktuah = Color.Lerp(Color.white, buuu, t2);
                updated222 += $"<color=#{ColorUtility.ToHtmlStringRGB(fucktuah)}>{duhh222[j2]}</color>";
                num222 = j2;
            }
            motd.GetComponent<TextMeshPro>().text = updated222;
            PhotonNetworkController.Instance.UpdateTriggerScreens();
        }
        public static Color fucktuah;
        public static void RecreateMenu()
        {
            if (menu != null)
            {
                UnityEngine.Object.Destroy(menu);
                menu = null;

                CreateMenu();
                RecenterMenu(rightHanded, UnityInput.Current.GetKey(keyboardButton));
            }
        }

        public static void RecenterMenu(bool isRightHanded, bool isKeyboardCondition)
        {
            if (!isKeyboardCondition)
            {
                if (!isRightHanded)
                {
                    if (flipMenu)
                    {
                        menu.transform.position = GorillaLocomotion.GTPlayer.Instance.leftControllerTransform.position;
                        Vector3 rotation = GorillaLocomotion.GTPlayer.Instance.leftControllerTransform.rotation.eulerAngles;
                        rotation += new Vector3(0f, 0f, 180f);
                        menu.transform.rotation = Quaternion.Euler(rotation);
                    }
                    else
                    {
                        menu.transform.position = GorillaLocomotion.GTPlayer.Instance.leftControllerTransform.position;
                        menu.transform.rotation = GorillaLocomotion.GTPlayer.Instance.leftControllerTransform.rotation;
                    }
                }
                else
                {
                    if (flipMenu)
                    {
                        menu.transform.position = GorillaLocomotion.GTPlayer.Instance.rightControllerTransform.position;
                        menu.transform.rotation = GorillaLocomotion.GTPlayer.Instance.rightControllerTransform.rotation;
                    }
                    else
                    {
                        menu.transform.position = GorillaLocomotion.GTPlayer.Instance.rightControllerTransform.position;
                        Vector3 rotation = GorillaLocomotion.GTPlayer.Instance.rightControllerTransform.rotation.eulerAngles;
                        rotation += new Vector3(0f, 0f, 180f);
                        menu.transform.rotation = Quaternion.Euler(rotation);
                    }
                }
            }
            else
            {
                try
                {
                    TPC = GameObject.Find("Player Objects/Third Person Camera/Shoulder Camera").GetComponent<Camera>();
                }
                catch { }

                GameObject.Find("Shoulder Camera").transform.Find("CM vcam1").gameObject.SetActive(false);

                if (TPC != null)
                {
                    TPC.transform.position = new Vector3(-999f, -999f, -999f);
                    TPC.transform.rotation = Quaternion.identity;
                    GameObject bg = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    bg.transform.localScale = new Vector3(10f, 10f, 0.01f);
                    bg.transform.transform.position = TPC.transform.position + TPC.transform.forward;
                    bg.GetComponent<Renderer>().material.color = new Color32((byte)(backgroundColor.colors[0].color.r * 50), (byte)(backgroundColor.colors[0].color.g * 50), (byte)(backgroundColor.colors[0].color.b * 50), 255);
                    GameObject.Destroy(bg, Time.deltaTime);
                    menu.transform.parent = TPC.transform;
                    menu.transform.position = (TPC.transform.position + (Vector3.Scale(TPC.transform.forward, new Vector3(0.5f, 0.5f, 0.5f)))) + (Vector3.Scale(TPC.transform.up, new Vector3(-0.02f, -0.02f, -0.02f)));
                    Vector3 rot = TPC.transform.rotation.eulerAngles;
                    rot = new Vector3(rot.x - 90, rot.y + 90, rot.z);
                    menu.transform.rotation = Quaternion.Euler(rot);
                    bg.GetComponent<Renderer>().enabled = false;
                    if (reference != null)
                    {
                        if (Mouse.current.leftButton.isPressed)
                        {
                            Ray ray = TPC.ScreenPointToRay(Mouse.current.position.ReadValue());
                            RaycastHit hit;
                            bool worked = Physics.Raycast(ray, out hit, 100);
                            if (worked)
                            {
                                Classes.Button collide = hit.transform.gameObject.GetComponent<Classes.Button>();
                                if (collide != null)
                                {
                                    collide.OnTriggerEnter(buttonCollider);
                                }
                            }
                        }
                        else
                        {
                            reference.transform.position = new Vector3(999f, -999f, -999f);
                        }
                    }
                }
            }
        }

        public static void CreateReference(bool isRightHanded)
        {
            reference = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            if (isRightHanded)
            {
                reference.transform.parent = GorillaTagger.Instance.leftHandTransform;
            }
            else
            {
                reference.transform.parent = GorillaTagger.Instance.rightHandTransform;
            }
            reference.GetComponent<Renderer>().material.color = backgroundColor.colors[0].color;
            reference.transform.localPosition = new Vector3(0f, -0.1f, 0f);
            reference.transform.localScale = new Vector3(0.01f, 0.01f, 0.01f);
            buttonCollider = reference.GetComponent<SphereCollider>();

            ColorChanger colorChanger = reference.AddComponent<ColorChanger>();
            colorChanger.colorInfo = backgroundColor;
            colorChanger.Start();
        }

        private static bool rightTriggerPressed = false;
        private static bool leftTriggerPressed = false;
        private static bool rightArrowPressed = false;
        private static bool leftArrowPressed = false;

        public static void NextPage()
        {
            if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f && !rightTriggerPressed)
            {
                Toggle("NextPage");
                rightTriggerPressed = true;
            }
            else if (ControllerInputPoller.instance.rightControllerIndexFloat <= 0.1f && rightTriggerPressed)
            {
                rightTriggerPressed = false;
            }
            if (UnityInput.Current.GetKey(KeyCode.RightArrow) && !rightArrowPressed)
            {
                Toggle("NextPage");
                rightArrowPressed = true;
            }
            else if (!UnityInput.Current.GetKey(KeyCode.RightArrow))
            {
                rightArrowPressed = false;
            }
        }

        public static void PreviousPage()
        {
            if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.1f && !leftTriggerPressed)
            {
                Toggle("PreviousPage");
                leftTriggerPressed = true;
            }
            else if (ControllerInputPoller.instance.leftControllerIndexFloat <= 0.1f && leftTriggerPressed)
            {
                leftTriggerPressed = false;
            }
            if (UnityInput.Current.GetKey(KeyCode.LeftArrow) && !leftArrowPressed)
            {
                Toggle("PreviousPage");
                leftArrowPressed = true;
            }
            else if (!UnityInput.Current.GetKey(KeyCode.LeftArrow))
            {
                leftArrowPressed = false;
            }
        }

        public static void Toggle(string buttonText)
        {
            int lastPage = ((buttons[buttonsType].Length + buttonsPerPage - 1) / buttonsPerPage) - 1;
            if (buttonText == "home")
            {
                Global.ReturnHome();
            }
            if (buttonText == "PreviousPage")
            {
                pageNumber--;
                if (pageNumber < 0)
                {
                    pageNumber = lastPage;
                }
            } else
            {
                if (buttonText == "NextPage")
                {
                    pageNumber++;
                    if (pageNumber > lastPage)
                    {
                        pageNumber = 0;
                    }
                } else
                {
                    ButtonInfo target = GetIndex(buttonText);
                    if (target != null)
                    {
                        if (target.isTogglable)
                        {
                            target.enabled = !target.enabled;
                            if (target.enabled)
                            {
                                if (target.enableMethod != null)
                                {
                                    try { target.enableMethod.Invoke(); } catch { }
                                }
                            }
                            else
                            {
                                if (target.disableMethod != null)
                                {
                                    try { target.disableMethod.Invoke(); } catch { }
                                }
                            }
                        }
                        else
                        {
                            if (target.method != null)
                            {
                                try { target.method.Invoke(); } catch { }
                            }
                        }
                    }
                    else
                    {
                        UnityEngine.Debug.LogError(buttonText + " does not exist");
                    }
                }
            }
            RecreateMenu();
        }

        public static GradientColorKey[] GetSolidGradient(Color color)
        {
            return new GradientColorKey[] { new GradientColorKey(color, 0f), new GradientColorKey(color, 1f) };
        }

        public static ButtonInfo GetIndex(string buttonText)
        {
            foreach (ButtonInfo[] buttons in Buttons.buttons)
            {
                foreach (ButtonInfo button in buttons)
                {
                    if (button.buttonText == buttonText)
                    {
                        return button;
                    }
                }
            }

            return null;
        }

        // Variables
            // Important
                // Objects
                    public static GameObject menu;
                    public static GameObject menuBackground;   
                    public static GameObject reference;
                    public static GameObject canvasObject;

                    public static SphereCollider buttonCollider;
                    public static Camera TPC;
                    public static Text fpsObject;

        // Data
            public static int pageNumber = 0;
            public static int buttonsType = 0;
    }
}
