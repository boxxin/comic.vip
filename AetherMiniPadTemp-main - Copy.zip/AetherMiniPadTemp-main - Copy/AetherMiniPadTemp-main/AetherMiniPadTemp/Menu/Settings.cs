﻿using AetherTemp.Classes;
using StupidTemplate.Classes;
using TMPro;
using UnityEngine;
using static StupidTemplate.Menu.Main;

namespace StupidTemplate
{
    internal class Settings
    {
        public static ExtGradient backgroundColor = new ExtGradient { colors = GetSolidGradient(new Color32(10, 10, 10, 255)) };
        public static ExtGradient[] buttonColors = new ExtGradient[]
        {
            new ExtGradient{colors = GetSolidGradient(new Color32(30, 30, 30, 255)) }, // Disabled
            new ExtGradient{colors = GetSolidGradient(new Color32(15, 15, 15, 255))} // Enabled
        };
        public static Color[] textColors = new Color[]
        {
            Color.white, // Disabled
            Color.white // Enabled
        };

        public static Font currentFont = Font.CreateDynamicFontFromOSFont("Comic Sans MS", 24);//(Resources.GetBuiltinResource(typeof(Font), "Arial.ttf") as Font);

        public static bool fpsCounter = false;
        public static bool disconnectButton = true;
        public static bool rightHanded = false;
        public static bool disableNotifications = false;
        public static bool pageButtons = false;
        public static bool disableMenuText = true;
        public static bool flipMenu = false;
        public static Color buuu = BetterColors.darkGrey;

        public static KeyCode keyboardButton = KeyCode.Q;

        public static Vector3 menuSize = new Vector3(0.1f, 0.6f, 0.75f); // Depth, Width, Height
        public static int buttonsPerPage = 6;
    }
}
